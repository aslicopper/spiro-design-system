# Spiro Design System — Figma Importer (v0.10)

A one-shot Figma development plugin that imports the Spiro v0.10 token system as native Figma Variables, Text Styles, and Effect Styles. No Tokens Studio. No third-party plugins.

## What it creates

  - **Spiro Color** — collection with `Light` and `Dark` modes.
    - Semantics first: `fg/*`, `bg/*`, `border/*`, `accent/*`, status (`danger / success / warning / info`), `decorative-fg/*`, `decorative-bg/*`. Includes `fg/contrast` + `bg/contrast` (theme-flipping pure black/white) and `fg/black`, `fg/white`, `bg/black`, `bg/white` (static pure).
    - Decorative-bg comes in three tones per family (`*-soft`, `*-bold`, `*-dark`) across 15 families (11 chromatic + 4 pastel-only).
    - Decorative-fg comes in two tones per family (`*-soft`, `*-bold`) across 11 chromatic families.
    - Primitives last: full chromatic palettes (blue, volt, zinc, red, …, rose) plus cream and navy backgrounds.
  - **Spiro Spacing** — 13-step ladder.
  - **Spiro Radius** — 10 steps including `radius/pill`.
  - **Spiro Stroke** — 4 widths (0, 1, 2, 3).
  - **Spiro Opacity** — 10-step ladder (0, 4, 8, 16, 24, 40, 56, 72, 88, 100 — stored as 0–1).
  - **Text Styles** — 28 numeric-named roles (display 72→30, heading 40→16, body 24→12, label 18→12 SemiBold/0%/UPPER, button 20→16, quote 36/24/20).
  - **Effect Styles** — 9 shadows (xs / sm / md / lg / xl / 2xl / inner / focus / focus-danger). Tuned for light surfaces; Effect Styles don't theme-flip in Figma.

Re-running the plugin updates everything in place. A cleanup pass deletes legacy variables and styles from earlier imports.

## Install

1. Download the `spiro-figma-importer/` folder.
2. Open Figma desktop (browser version doesn't support development plugins).
3. Open any Figma file.
4. Menu → *Plugins* → *Development* → *Import plugin from manifest…* → pick `spiro-figma-importer/manifest.json`.

The plugin appears under *Plugins* → *Development* → *Spiro Design System Importer*.

## Run

1. Run from the menu above.
2. Three checkboxes — Variables, Text Styles, Effect Styles. All on by default.
3. Click *Import to this file*.
4. Console reports created / updated / skipped per section.

## Fonts required

The text-style import looks up these fonts on the local machine:

  - **Clash Grotesk** — fontshare.com/fonts/clash-grotesk (Bold + Semibold)
  - **DM Sans** — Google Fonts (Regular, Medium, SemiBold, Bold)
  - **Kalam** — Google Fonts (Regular, Bold)

Missing fonts cause the affected text styles to be skipped (logged in the console). Install the font, restart Figma, re-run the plugin to fill in.

## Updating

When tokens change, re-export the plugin and re-run. Existing variables / styles match by name and update; nothing duplicates.

---

Spiro Design System · v0.10 · April 2026
