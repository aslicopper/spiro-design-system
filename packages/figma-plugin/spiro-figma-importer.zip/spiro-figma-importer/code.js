/**
 * Spiro Design System Importer (v0.16)
 *
 * - Variables (Spiro Color/Spacing/Radius/Stroke/Opacity)
 * - Text Styles, Effect Styles, Paint Styles (gradients)
 * - Components: Button, Chip, Input, Badge, Switch, Checkbox, Radio, Tabs, Alert
 *   • Geometry (cornerRadius / padding / itemSpacing / strokeWeight) is
 *     bound to variables — change a token, every component updates.
 *   • Button / Chip / Tabs / Input have an Icon variant (none/prefix/suffix).
 *     Alert has a with/without-icon variant. Icon is a circle placeholder
 *     for designers to swap in real icons.
 */

const DATA = {"version":"0.16","obsoleteVariables":["color/stone/25","color/stone/50","color/stone/100","color/stone/200","color/stone/300","color/stone/400","color/stone/500","color/stone/600","color/stone/700","color/stone/800","color/stone/900","color/stone/950","color/stone/975","bg/lavender/50","bg/lavender/100","bg/mint/50","bg/mint/100","bg/peach/50","bg/peach/100","bg/periwinkle/50","bg/periwinkle/100","bg/section/lavender","bg/section/mint","bg/section/peach","bg/section/periwinkle","decorative/orange","decorative/orangeBg","decorative-bg/lavender/soft","decorative-bg/lavender/bold","decorative-bg/mint/soft","decorative-bg/mint/bold","decorative-bg/peach/soft","decorative-bg/peach/bold","decorative-bg/periwinkle/soft","decorative-bg/periwinkle/bold","decorative-fg/orange","decorative-fg/amber","decorative-fg/yellow","decorative-fg/lime","decorative-fg/emerald","decorative-fg/cyan","decorative-fg/sky","decorative-fg/indigo","decorative-fg/violet","decorative-fg/pink","decorative-fg/rose","opacity/4","opacity/8","opacity/16","opacity/24","opacity/40","opacity/56","opacity/72","opacity/88","accent/active"],"obsoleteTextStyles":["display-xl","display-lg","display-md","display-sm","display-xs","heading-xl","heading-lg","heading-md","heading-sm","body-xs","body-sm","body-md","body-lg","label-sm","label-lg","quote","accent","accent-20","amount-lg","amount-md"],"collections":[{"name":"Spiro Color","modes":["Light","Dark"],"variables":[{"name":"fg/default","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#18181B","Dark":"#FBFAF7"}},{"name":"fg/muted","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#52525B","Dark":"#A1A1AA"}},{"name":"fg/subtle","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#71717A","Dark":"#71717A"}},{"name":"fg/onAccent","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#FBFAF7","Dark":"#FBFAF7"}},{"name":"fg/onInverse","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#FBFAF7","Dark":"#18181B"}},{"name":"fg/onLight","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#18181B","Dark":"#18181B"}},{"name":"fg/muted-blend","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#18181B99","Dark":"#FBFAF799"}},{"name":"fg/subtle-blend","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#18181B66","Dark":"#FBFAF766"}},{"name":"fg/contrast","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#FFFFFF","Dark":"#000000"}},{"name":"fg/black","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#000000","Dark":"#000000"}},{"name":"fg/white","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#FFFFFF","Dark":"#FFFFFF"}},{"name":"bg/canvas","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#FBFAF7","Dark":"#0F0E25"}},{"name":"bg/default","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#18181B","Dark":"#FBFAF7"}},{"name":"bg/subtle","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#F6F4EE","Dark":"#1A1833"}},{"name":"bg/muted","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#EEEBE1","Dark":"#27272A"}},{"name":"bg/inverse","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#0F0E25","Dark":"#FBFAF7"}},{"name":"bg/blend","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#0F0E250F","Dark":"#FBFAF70F"}},{"name":"bg/contrast","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#FFFFFF","Dark":"#000000"}},{"name":"bg/black","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#000000","Dark":"#000000"}},{"name":"bg/white","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#FFFFFF","Dark":"#FFFFFF"}},{"name":"border/subtle","type":"COLOR","scopes":["STROKE_COLOR"],"valuesByMode":{"Light":"#F4F4F5","Dark":"#18181B"}},{"name":"border/default","type":"COLOR","scopes":["STROKE_COLOR"],"valuesByMode":{"Light":"#E4E4E7","Dark":"#27272A"}},{"name":"border/strong","type":"COLOR","scopes":["STROKE_COLOR"],"valuesByMode":{"Light":"#D4D4D8","Dark":"#3F3F46"}},{"name":"border/blend","type":"COLOR","scopes":["STROKE_COLOR"],"valuesByMode":{"Light":"#71717A33","Dark":"#71717A33"}},{"name":"border/focus","type":"COLOR","scopes":["STROKE_COLOR"],"valuesByMode":{"Light":"#3038FC","Dark":"#5F6EFD"}},{"name":"border/inverse","type":"COLOR","scopes":["STROKE_COLOR"],"valuesByMode":{"Light":"#FBFAF7","Dark":"#0F0E25"}},{"name":"accent/default","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#3038FC","Dark":"#5F6EFD"}},{"name":"accent/hover","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#1F27E5","Dark":"#8D98FD"}},{"name":"accent/pressed","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#181EB8","Dark":"#3038FC"}},{"name":"accent/selected","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#3038FC","Dark":"#5F6EFD"}},{"name":"accent/deselected","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#EEF0FF","Dark":"#181EB866"}},{"name":"accent/selected-fg","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#FBFAF7","Dark":"#FBFAF7"}},{"name":"accent/deselected-fg","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#181EB8","Dark":"#8D98FD"}},{"name":"accent/subtle","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#EEF0FF","Dark":"#151A8F"}},{"name":"danger/bg","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#FEF2F2","Dark":"#7F1D1D"}},{"name":"danger/default","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#DC2626","Dark":"#F87171"}},{"name":"danger/fg","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#B91C1C","Dark":"#FCA5A5"}},{"name":"danger/hover","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#B91C1C","Dark":"#FCA5A5"}},{"name":"success/bg","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#ECFDF5","Dark":"#064E3B"}},{"name":"success/default","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#059669","Dark":"#34D399"}},{"name":"success/fg","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#047857","Dark":"#6EE7B7"}},{"name":"success/hover","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#047857","Dark":"#6EE7B7"}},{"name":"warning/bg","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#FFFBEB","Dark":"#78350F"}},{"name":"warning/default","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#F59E0B","Dark":"#FBBF24"}},{"name":"warning/fg","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#92400E","Dark":"#FCD34D"}},{"name":"warning/hover","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#D97706","Dark":"#FCD34D"}},{"name":"info/bg","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#F0F9FF","Dark":"#0C4A6E"}},{"name":"info/default","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#0EA5E9","Dark":"#38BDF8"}},{"name":"info/fg","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#0369A1","Dark":"#7DD3FC"}},{"name":"info/hover","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR"],"valuesByMode":{"Light":"#0284C7","Dark":"#7DD3FC"}},{"name":"decorative-fg/blue-soft","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#8D98FD","Dark":"#B7BEFE"}},{"name":"decorative-fg/blue-bold","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#3038FC","Dark":"#5F6EFD"}},{"name":"decorative-fg/blue-dark","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#181EB8","Dark":"#1F27E5"}},{"name":"decorative-fg/orange-soft","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FDBA74","Dark":"#FED7AA"}},{"name":"decorative-fg/orange-bold","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F97316","Dark":"#FB923C"}},{"name":"decorative-fg/orange-dark","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#C2410C","Dark":"#EA580C"}},{"name":"decorative-fg/amber-soft","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FCD34D","Dark":"#FDE68A"}},{"name":"decorative-fg/amber-bold","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F59E0B","Dark":"#FBBF24"}},{"name":"decorative-fg/amber-dark","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#B45309","Dark":"#D97706"}},{"name":"decorative-fg/yellow-soft","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FDE047","Dark":"#FEF08A"}},{"name":"decorative-fg/yellow-bold","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#EAB308","Dark":"#FACC15"}},{"name":"decorative-fg/yellow-dark","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#A16207","Dark":"#CA8A04"}},{"name":"decorative-fg/lime-soft","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#BEF264","Dark":"#D9F99D"}},{"name":"decorative-fg/lime-bold","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#84CC16","Dark":"#A3E635"}},{"name":"decorative-fg/lime-dark","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#4D7C0F","Dark":"#65A30D"}},{"name":"decorative-fg/emerald-soft","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#6EE7B7","Dark":"#A7F3D0"}},{"name":"decorative-fg/emerald-bold","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#10B981","Dark":"#34D399"}},{"name":"decorative-fg/emerald-dark","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#047857","Dark":"#059669"}},{"name":"decorative-fg/cyan-soft","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#67E8F9","Dark":"#A5F3FC"}},{"name":"decorative-fg/cyan-bold","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#06B6D4","Dark":"#22D3EE"}},{"name":"decorative-fg/cyan-dark","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#0E7490","Dark":"#0891B2"}},{"name":"decorative-fg/sky-soft","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#7DD3FC","Dark":"#BAE6FD"}},{"name":"decorative-fg/sky-bold","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#0EA5E9","Dark":"#38BDF8"}},{"name":"decorative-fg/sky-dark","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#0369A1","Dark":"#0284C7"}},{"name":"decorative-fg/indigo-soft","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#A5B4FC","Dark":"#C7D2FE"}},{"name":"decorative-fg/indigo-bold","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#6366F1","Dark":"#818CF8"}},{"name":"decorative-fg/indigo-dark","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#4338CA","Dark":"#4F46E5"}},{"name":"decorative-fg/violet-soft","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#C4B5FD","Dark":"#DDD6FE"}},{"name":"decorative-fg/violet-bold","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#8B5CF6","Dark":"#A78BFA"}},{"name":"decorative-fg/violet-dark","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#6D28D9","Dark":"#7C3AED"}},{"name":"decorative-fg/pink-soft","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F9A8D4","Dark":"#FBCFE8"}},{"name":"decorative-fg/pink-bold","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#EC4899","Dark":"#F472B6"}},{"name":"decorative-fg/pink-dark","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#BE185D","Dark":"#DB2777"}},{"name":"decorative-fg/rose-soft","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FDA4AF","Dark":"#FECDD3"}},{"name":"decorative-fg/rose-bold","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F43F5E","Dark":"#FB7185"}},{"name":"decorative-fg/rose-dark","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#BE123C","Dark":"#E11D48"}},{"name":"decorative-fg/red-soft","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FCA5A5","Dark":"#FECACA"}},{"name":"decorative-fg/red-bold","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#EF4444","Dark":"#F87171"}},{"name":"decorative-fg/red-dark","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#B91C1C","Dark":"#DC2626"}},{"name":"decorative-fg/cream-soft","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FBFAF7","Dark":"#FBFAF7"}},{"name":"decorative-fg/cream-bold","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F6F4EE","Dark":"#F6F4EE"}},{"name":"decorative-fg/cream-dark","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#EEEBE1","Dark":"#EEEBE1"}},{"name":"decorative-fg/navy-soft","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#1A1833","Dark":"#1A1833"}},{"name":"decorative-fg/navy-bold","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#0F0E25","Dark":"#0F0E25"}},{"name":"decorative-fg/navy-dark","type":"COLOR","scopes":["TEXT_FILL","SHAPE_FILL","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#070612","Dark":"#070612"}},{"name":"decorative-bg/blue-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#EEF0FF","Dark":"#080B3D"}},{"name":"decorative-bg/blue-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#DADCFF","Dark":"#10166B"}},{"name":"decorative-bg/blue-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#151A8F","Dark":"#181EB8"}},{"name":"decorative-bg/orange-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#FFF7ED","Dark":"#431407"}},{"name":"decorative-bg/orange-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#FFEDD5","Dark":"#7C2D12"}},{"name":"decorative-bg/orange-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#9A3412","Dark":"#C2410C"}},{"name":"decorative-bg/amber-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#FFFBEB","Dark":"#451A03"}},{"name":"decorative-bg/amber-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#FEF3C7","Dark":"#78350F"}},{"name":"decorative-bg/amber-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#92400E","Dark":"#B45309"}},{"name":"decorative-bg/yellow-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#FEFCE8","Dark":"#422006"}},{"name":"decorative-bg/yellow-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#FEF9C3","Dark":"#713F12"}},{"name":"decorative-bg/yellow-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#854D0E","Dark":"#A16207"}},{"name":"decorative-bg/lime-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#F7FEE7","Dark":"#1A2E05"}},{"name":"decorative-bg/lime-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#ECFCCB","Dark":"#365314"}},{"name":"decorative-bg/lime-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#3F6212","Dark":"#4D7C0F"}},{"name":"decorative-bg/emerald-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#ECFDF5","Dark":"#022C22"}},{"name":"decorative-bg/emerald-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#D1FAE5","Dark":"#064E3B"}},{"name":"decorative-bg/emerald-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#065F46","Dark":"#047857"}},{"name":"decorative-bg/cyan-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#ECFEFF","Dark":"#083344"}},{"name":"decorative-bg/cyan-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#CFFAFE","Dark":"#164E63"}},{"name":"decorative-bg/cyan-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#155E75","Dark":"#0E7490"}},{"name":"decorative-bg/sky-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#F0F9FF","Dark":"#082F49"}},{"name":"decorative-bg/sky-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#E0F2FE","Dark":"#0C4A6E"}},{"name":"decorative-bg/sky-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#075985","Dark":"#0369A1"}},{"name":"decorative-bg/indigo-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#EEF2FF","Dark":"#1E1B4B"}},{"name":"decorative-bg/indigo-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#E0E7FF","Dark":"#312E81"}},{"name":"decorative-bg/indigo-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#3730A3","Dark":"#4338CA"}},{"name":"decorative-bg/violet-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#F5F3FF","Dark":"#2E1065"}},{"name":"decorative-bg/violet-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#EDE9FE","Dark":"#4C1D95"}},{"name":"decorative-bg/violet-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#5B21B6","Dark":"#6D28D9"}},{"name":"decorative-bg/pink-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#FDF2F8","Dark":"#500724"}},{"name":"decorative-bg/pink-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#FCE7F3","Dark":"#831843"}},{"name":"decorative-bg/pink-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#9D174D","Dark":"#BE185D"}},{"name":"decorative-bg/rose-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#FFF1F2","Dark":"#4C0519"}},{"name":"decorative-bg/rose-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#FFE4E6","Dark":"#881337"}},{"name":"decorative-bg/rose-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#9F1239","Dark":"#BE123C"}},{"name":"decorative-bg/red-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#FEF2F2","Dark":"#450A0A"}},{"name":"decorative-bg/red-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#FEE2E2","Dark":"#7F1D1D"}},{"name":"decorative-bg/red-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#991B1B","Dark":"#B91C1C"}},{"name":"decorative-bg/lavender-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#F2F1F6","Dark":"#2E1065"}},{"name":"decorative-bg/lavender-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#E5E3EB","Dark":"#4C1D95"}},{"name":"decorative-bg/lavender-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#5B21B6","Dark":"#6D28D9"}},{"name":"decorative-bg/mint-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#E9F2EC","Dark":"#022C22"}},{"name":"decorative-bg/mint-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#DCE8DF","Dark":"#064E3B"}},{"name":"decorative-bg/mint-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#065F46","Dark":"#047857"}},{"name":"decorative-bg/peach-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#F1ECE3","Dark":"#451A03"}},{"name":"decorative-bg/peach-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#E5D8C7","Dark":"#78350F"}},{"name":"decorative-bg/peach-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#92400E","Dark":"#B45309"}},{"name":"decorative-bg/periwinkle-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#E8EDF3","Dark":"#1E1B4B"}},{"name":"decorative-bg/periwinkle-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#DBE4ED","Dark":"#312E81"}},{"name":"decorative-bg/periwinkle-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#3730A3","Dark":"#4338CA"}},{"name":"decorative-bg/cream-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#FBFAF7","Dark":"#FBFAF7"}},{"name":"decorative-bg/cream-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#F6F4EE","Dark":"#F6F4EE"}},{"name":"decorative-bg/cream-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#EEEBE1","Dark":"#EEEBE1"}},{"name":"decorative-bg/navy-soft","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#1A1833","Dark":"#1A1833"}},{"name":"decorative-bg/navy-bold","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#0F0E25","Dark":"#0F0E25"}},{"name":"decorative-bg/navy-dark","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL"],"valuesByMode":{"Light":"#070612","Dark":"#070612"}},{"name":"color/blue/25","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F6F7FF","Dark":"#F6F7FF"}},{"name":"color/blue/50","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#EEF0FF","Dark":"#EEF0FF"}},{"name":"color/blue/100","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#DADCFF","Dark":"#DADCFF"}},{"name":"color/blue/200","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#B7BEFE","Dark":"#B7BEFE"}},{"name":"color/blue/300","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#8D98FD","Dark":"#8D98FD"}},{"name":"color/blue/400","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#5F6EFD","Dark":"#5F6EFD"}},{"name":"color/blue/500","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#3038FC","Dark":"#3038FC"}},{"name":"color/blue/600","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#1F27E5","Dark":"#1F27E5"}},{"name":"color/blue/700","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#181EB8","Dark":"#181EB8"}},{"name":"color/blue/800","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#151A8F","Dark":"#151A8F"}},{"name":"color/blue/900","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#10166B","Dark":"#10166B"}},{"name":"color/blue/950","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#080B3D","Dark":"#080B3D"}},{"name":"color/blue/975","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#04061F","Dark":"#04061F"}},{"name":"color/volt/25","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FDFFF2","Dark":"#FDFFF2"}},{"name":"color/volt/50","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FBFFE5","Dark":"#FBFFE5"}},{"name":"color/volt/100","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F4FFBE","Dark":"#F4FFBE"}},{"name":"color/volt/200","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#ECFF8A","Dark":"#ECFF8A"}},{"name":"color/volt/300","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#E6FF57","Dark":"#E6FF57"}},{"name":"color/volt/400","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#E2FF2C","Dark":"#E2FF2C"}},{"name":"color/volt/500","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#DFFF04","Dark":"#DFFF04"}},{"name":"color/volt/600","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#C5E500","Dark":"#C5E500"}},{"name":"color/volt/700","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#9EB800","Dark":"#9EB800"}},{"name":"color/volt/800","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#7B8F00","Dark":"#7B8F00"}},{"name":"color/volt/900","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#5C6B00","Dark":"#5C6B00"}},{"name":"color/volt/950","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#2B3100","Dark":"#2B3100"}},{"name":"color/volt/975","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#141800","Dark":"#141800"}},{"name":"color/zinc/25","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FCFCFC","Dark":"#FCFCFC"}},{"name":"color/zinc/50","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FAFAFA","Dark":"#FAFAFA"}},{"name":"color/zinc/100","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F4F4F5","Dark":"#F4F4F5"}},{"name":"color/zinc/200","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#E4E4E7","Dark":"#E4E4E7"}},{"name":"color/zinc/300","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#D4D4D8","Dark":"#D4D4D8"}},{"name":"color/zinc/400","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#A1A1AA","Dark":"#A1A1AA"}},{"name":"color/zinc/500","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#71717A","Dark":"#71717A"}},{"name":"color/zinc/600","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#52525B","Dark":"#52525B"}},{"name":"color/zinc/700","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#3F3F46","Dark":"#3F3F46"}},{"name":"color/zinc/800","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#27272A","Dark":"#27272A"}},{"name":"color/zinc/900","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#18181B","Dark":"#18181B"}},{"name":"color/zinc/950","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#09090B","Dark":"#09090B"}},{"name":"color/zinc/975","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#040405","Dark":"#040405"}},{"name":"color/red/25","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FEF8F8","Dark":"#FEF8F8"}},{"name":"color/red/50","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FEF2F2","Dark":"#FEF2F2"}},{"name":"color/red/100","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FEE2E2","Dark":"#FEE2E2"}},{"name":"color/red/200","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FECACA","Dark":"#FECACA"}},{"name":"color/red/300","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FCA5A5","Dark":"#FCA5A5"}},{"name":"color/red/400","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F87171","Dark":"#F87171"}},{"name":"color/red/500","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#EF4444","Dark":"#EF4444"}},{"name":"color/red/600","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#DC2626","Dark":"#DC2626"}},{"name":"color/red/700","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#B91C1C","Dark":"#B91C1C"}},{"name":"color/red/800","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#991B1B","Dark":"#991B1B"}},{"name":"color/red/900","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#7F1D1D","Dark":"#7F1D1D"}},{"name":"color/red/950","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#450A0A","Dark":"#450A0A"}},{"name":"color/red/975","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#240505","Dark":"#240505"}},{"name":"color/orange/25","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FFFBF6","Dark":"#FFFBF6"}},{"name":"color/orange/50","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FFF7ED","Dark":"#FFF7ED"}},{"name":"color/orange/100","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FFEDD5","Dark":"#FFEDD5"}},{"name":"color/orange/200","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FED7AA","Dark":"#FED7AA"}},{"name":"color/orange/300","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FDBA74","Dark":"#FDBA74"}},{"name":"color/orange/400","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FB923C","Dark":"#FB923C"}},{"name":"color/orange/500","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F97316","Dark":"#F97316"}},{"name":"color/orange/600","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#EA580C","Dark":"#EA580C"}},{"name":"color/orange/700","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#C2410C","Dark":"#C2410C"}},{"name":"color/orange/800","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#9A3412","Dark":"#9A3412"}},{"name":"color/orange/900","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#7C2D12","Dark":"#7C2D12"}},{"name":"color/orange/950","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#431407","Dark":"#431407"}},{"name":"color/orange/975","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#220A03","Dark":"#220A03"}},{"name":"color/amber/25","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FFFDF5","Dark":"#FFFDF5"}},{"name":"color/amber/50","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FFFBEB","Dark":"#FFFBEB"}},{"name":"color/amber/100","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FEF3C7","Dark":"#FEF3C7"}},{"name":"color/amber/200","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FDE68A","Dark":"#FDE68A"}},{"name":"color/amber/300","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FCD34D","Dark":"#FCD34D"}},{"name":"color/amber/400","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FBBF24","Dark":"#FBBF24"}},{"name":"color/amber/500","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F59E0B","Dark":"#F59E0B"}},{"name":"color/amber/600","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#D97706","Dark":"#D97706"}},{"name":"color/amber/700","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#B45309","Dark":"#B45309"}},{"name":"color/amber/800","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#92400E","Dark":"#92400E"}},{"name":"color/amber/900","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#78350F","Dark":"#78350F"}},{"name":"color/amber/950","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#451A03","Dark":"#451A03"}},{"name":"color/amber/975","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#240D01","Dark":"#240D01"}},{"name":"color/yellow/25","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FEFDF3","Dark":"#FEFDF3"}},{"name":"color/yellow/50","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FEFCE8","Dark":"#FEFCE8"}},{"name":"color/yellow/100","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FEF9C3","Dark":"#FEF9C3"}},{"name":"color/yellow/200","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FEF08A","Dark":"#FEF08A"}},{"name":"color/yellow/300","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FDE047","Dark":"#FDE047"}},{"name":"color/yellow/400","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FACC15","Dark":"#FACC15"}},{"name":"color/yellow/500","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#EAB308","Dark":"#EAB308"}},{"name":"color/yellow/600","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#CA8A04","Dark":"#CA8A04"}},{"name":"color/yellow/700","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#A16207","Dark":"#A16207"}},{"name":"color/yellow/800","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#854D0E","Dark":"#854D0E"}},{"name":"color/yellow/900","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#713F12","Dark":"#713F12"}},{"name":"color/yellow/950","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#422006","Dark":"#422006"}},{"name":"color/yellow/975","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#211002","Dark":"#211002"}},{"name":"color/lime/25","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FAFFE8","Dark":"#FAFFE8"}},{"name":"color/lime/50","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F7FEE7","Dark":"#F7FEE7"}},{"name":"color/lime/100","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#ECFCCB","Dark":"#ECFCCB"}},{"name":"color/lime/200","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#D9F99D","Dark":"#D9F99D"}},{"name":"color/lime/300","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#BEF264","Dark":"#BEF264"}},{"name":"color/lime/400","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#A3E635","Dark":"#A3E635"}},{"name":"color/lime/500","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#84CC16","Dark":"#84CC16"}},{"name":"color/lime/600","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#65A30D","Dark":"#65A30D"}},{"name":"color/lime/700","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#4D7C0F","Dark":"#4D7C0F"}},{"name":"color/lime/800","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#3F6212","Dark":"#3F6212"}},{"name":"color/lime/900","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#365314","Dark":"#365314"}},{"name":"color/lime/950","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#1A2E05","Dark":"#1A2E05"}},{"name":"color/lime/975","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#0D1702","Dark":"#0D1702"}},{"name":"color/emerald/25","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F3FEF8","Dark":"#F3FEF8"}},{"name":"color/emerald/50","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#ECFDF5","Dark":"#ECFDF5"}},{"name":"color/emerald/100","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#D1FAE5","Dark":"#D1FAE5"}},{"name":"color/emerald/200","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#A7F3D0","Dark":"#A7F3D0"}},{"name":"color/emerald/300","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#6EE7B7","Dark":"#6EE7B7"}},{"name":"color/emerald/400","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#34D399","Dark":"#34D399"}},{"name":"color/emerald/500","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#10B981","Dark":"#10B981"}},{"name":"color/emerald/600","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#059669","Dark":"#059669"}},{"name":"color/emerald/700","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#047857","Dark":"#047857"}},{"name":"color/emerald/800","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#065F46","Dark":"#065F46"}},{"name":"color/emerald/900","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#064E3B","Dark":"#064E3B"}},{"name":"color/emerald/950","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#022C22","Dark":"#022C22"}},{"name":"color/emerald/975","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#011610","Dark":"#011610"}},{"name":"color/cyan/25","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F2FDFE","Dark":"#F2FDFE"}},{"name":"color/cyan/50","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#ECFEFF","Dark":"#ECFEFF"}},{"name":"color/cyan/100","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#CFFAFE","Dark":"#CFFAFE"}},{"name":"color/cyan/200","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#A5F3FC","Dark":"#A5F3FC"}},{"name":"color/cyan/300","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#67E8F9","Dark":"#67E8F9"}},{"name":"color/cyan/400","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#22D3EE","Dark":"#22D3EE"}},{"name":"color/cyan/500","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#06B6D4","Dark":"#06B6D4"}},{"name":"color/cyan/600","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#0891B2","Dark":"#0891B2"}},{"name":"color/cyan/700","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#0E7490","Dark":"#0E7490"}},{"name":"color/cyan/800","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#155E75","Dark":"#155E75"}},{"name":"color/cyan/900","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#164E63","Dark":"#164E63"}},{"name":"color/cyan/950","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#083344","Dark":"#083344"}},{"name":"color/cyan/975","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#041B24","Dark":"#041B24"}},{"name":"color/sky/25","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F6FCFF","Dark":"#F6FCFF"}},{"name":"color/sky/50","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F0F9FF","Dark":"#F0F9FF"}},{"name":"color/sky/100","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#E0F2FE","Dark":"#E0F2FE"}},{"name":"color/sky/200","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#BAE6FD","Dark":"#BAE6FD"}},{"name":"color/sky/300","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#7DD3FC","Dark":"#7DD3FC"}},{"name":"color/sky/400","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#38BDF8","Dark":"#38BDF8"}},{"name":"color/sky/500","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#0EA5E9","Dark":"#0EA5E9"}},{"name":"color/sky/600","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#0284C7","Dark":"#0284C7"}},{"name":"color/sky/700","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#0369A1","Dark":"#0369A1"}},{"name":"color/sky/800","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#075985","Dark":"#075985"}},{"name":"color/sky/900","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#0C4A6E","Dark":"#0C4A6E"}},{"name":"color/sky/950","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#082F49","Dark":"#082F49"}},{"name":"color/sky/975","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#041825","Dark":"#041825"}},{"name":"color/indigo/25","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F7F8FF","Dark":"#F7F8FF"}},{"name":"color/indigo/50","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#EEF2FF","Dark":"#EEF2FF"}},{"name":"color/indigo/100","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#E0E7FF","Dark":"#E0E7FF"}},{"name":"color/indigo/200","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#C7D2FE","Dark":"#C7D2FE"}},{"name":"color/indigo/300","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#A5B4FC","Dark":"#A5B4FC"}},{"name":"color/indigo/400","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#818CF8","Dark":"#818CF8"}},{"name":"color/indigo/500","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#6366F1","Dark":"#6366F1"}},{"name":"color/indigo/600","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#4F46E5","Dark":"#4F46E5"}},{"name":"color/indigo/700","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#4338CA","Dark":"#4338CA"}},{"name":"color/indigo/800","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#3730A3","Dark":"#3730A3"}},{"name":"color/indigo/900","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#312E81","Dark":"#312E81"}},{"name":"color/indigo/950","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#1E1B4B","Dark":"#1E1B4B"}},{"name":"color/indigo/975","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#0F0D25","Dark":"#0F0D25"}},{"name":"color/violet/25","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F9F7FF","Dark":"#F9F7FF"}},{"name":"color/violet/50","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F5F3FF","Dark":"#F5F3FF"}},{"name":"color/violet/100","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#EDE9FE","Dark":"#EDE9FE"}},{"name":"color/violet/200","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#DDD6FE","Dark":"#DDD6FE"}},{"name":"color/violet/300","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#C4B5FD","Dark":"#C4B5FD"}},{"name":"color/violet/400","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#A78BFA","Dark":"#A78BFA"}},{"name":"color/violet/500","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#8B5CF6","Dark":"#8B5CF6"}},{"name":"color/violet/600","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#7C3AED","Dark":"#7C3AED"}},{"name":"color/violet/700","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#6D28D9","Dark":"#6D28D9"}},{"name":"color/violet/800","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#5B21B6","Dark":"#5B21B6"}},{"name":"color/violet/900","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#4C1D95","Dark":"#4C1D95"}},{"name":"color/violet/950","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#2E1065","Dark":"#2E1065"}},{"name":"color/violet/975","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#170830","Dark":"#170830"}},{"name":"color/pink/25","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FFF5FA","Dark":"#FFF5FA"}},{"name":"color/pink/50","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FDF2F8","Dark":"#FDF2F8"}},{"name":"color/pink/100","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FCE7F3","Dark":"#FCE7F3"}},{"name":"color/pink/200","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FBCFE8","Dark":"#FBCFE8"}},{"name":"color/pink/300","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F9A8D4","Dark":"#F9A8D4"}},{"name":"color/pink/400","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F472B6","Dark":"#F472B6"}},{"name":"color/pink/500","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#EC4899","Dark":"#EC4899"}},{"name":"color/pink/600","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#DB2777","Dark":"#DB2777"}},{"name":"color/pink/700","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#BE185D","Dark":"#BE185D"}},{"name":"color/pink/800","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#9D174D","Dark":"#9D174D"}},{"name":"color/pink/900","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#831843","Dark":"#831843"}},{"name":"color/pink/950","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#500724","Dark":"#500724"}},{"name":"color/pink/975","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#280412","Dark":"#280412"}},{"name":"color/rose/25","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FFF6F7","Dark":"#FFF6F7"}},{"name":"color/rose/50","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FFF1F2","Dark":"#FFF1F2"}},{"name":"color/rose/100","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FFE4E6","Dark":"#FFE4E6"}},{"name":"color/rose/200","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FECDD3","Dark":"#FECDD3"}},{"name":"color/rose/300","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FDA4AF","Dark":"#FDA4AF"}},{"name":"color/rose/400","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#FB7185","Dark":"#FB7185"}},{"name":"color/rose/500","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#F43F5E","Dark":"#F43F5E"}},{"name":"color/rose/600","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#E11D48","Dark":"#E11D48"}},{"name":"color/rose/700","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#BE123C","Dark":"#BE123C"}},{"name":"color/rose/800","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#9F1239","Dark":"#9F1239"}},{"name":"color/rose/900","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#881337","Dark":"#881337"}},{"name":"color/rose/950","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#4C0519","Dark":"#4C0519"}},{"name":"color/rose/975","type":"COLOR","scopes":["ALL_FILLS","STROKE_COLOR","EFFECT_COLOR"],"valuesByMode":{"Light":"#26020D","Dark":"#26020D"}},{"name":"bg/cream/25","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#FBFAF7","Dark":"#FBFAF7"}},{"name":"bg/cream/50","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#F6F4EE","Dark":"#F6F4EE"}},{"name":"bg/cream/100","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#EEEBE1","Dark":"#EEEBE1"}},{"name":"bg/navy/900","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#1A1833","Dark":"#1A1833"}},{"name":"bg/navy/950","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#0F0E25","Dark":"#0F0E25"}},{"name":"bg/navy/975","type":"COLOR","scopes":["FRAME_FILL","SHAPE_FILL","STROKE_COLOR"],"valuesByMode":{"Light":"#070612","Dark":"#070612"}}]},{"name":"Spiro Spacing","modes":["Default"],"variables":[{"name":"space/0","type":"FLOAT","scopes":["GAP","WIDTH_HEIGHT"],"valuesByMode":{"Default":0.0}},{"name":"space/1","type":"FLOAT","scopes":["GAP","WIDTH_HEIGHT"],"valuesByMode":{"Default":4.0}},{"name":"space/2","type":"FLOAT","scopes":["GAP","WIDTH_HEIGHT"],"valuesByMode":{"Default":8.0}},{"name":"space/3","type":"FLOAT","scopes":["GAP","WIDTH_HEIGHT"],"valuesByMode":{"Default":12.0}},{"name":"space/4","type":"FLOAT","scopes":["GAP","WIDTH_HEIGHT"],"valuesByMode":{"Default":16.0}},{"name":"space/5","type":"FLOAT","scopes":["GAP","WIDTH_HEIGHT"],"valuesByMode":{"Default":20.0}},{"name":"space/6","type":"FLOAT","scopes":["GAP","WIDTH_HEIGHT"],"valuesByMode":{"Default":24.0}},{"name":"space/8","type":"FLOAT","scopes":["GAP","WIDTH_HEIGHT"],"valuesByMode":{"Default":32.0}},{"name":"space/10","type":"FLOAT","scopes":["GAP","WIDTH_HEIGHT"],"valuesByMode":{"Default":40.0}},{"name":"space/12","type":"FLOAT","scopes":["GAP","WIDTH_HEIGHT"],"valuesByMode":{"Default":48.0}},{"name":"space/16","type":"FLOAT","scopes":["GAP","WIDTH_HEIGHT"],"valuesByMode":{"Default":64.0}},{"name":"space/20","type":"FLOAT","scopes":["GAP","WIDTH_HEIGHT"],"valuesByMode":{"Default":80.0}}]},{"name":"Spiro Radius","modes":["Default"],"variables":[{"name":"radius/0","type":"FLOAT","scopes":["CORNER_RADIUS"],"valuesByMode":{"Default":0.0}},{"name":"radius/2","type":"FLOAT","scopes":["CORNER_RADIUS"],"valuesByMode":{"Default":2.0}},{"name":"radius/4","type":"FLOAT","scopes":["CORNER_RADIUS"],"valuesByMode":{"Default":4.0}},{"name":"radius/8","type":"FLOAT","scopes":["CORNER_RADIUS"],"valuesByMode":{"Default":8.0}},{"name":"radius/12","type":"FLOAT","scopes":["CORNER_RADIUS"],"valuesByMode":{"Default":12.0}},{"name":"radius/16","type":"FLOAT","scopes":["CORNER_RADIUS"],"valuesByMode":{"Default":16.0}},{"name":"radius/24","type":"FLOAT","scopes":["CORNER_RADIUS"],"valuesByMode":{"Default":24.0}},{"name":"radius/32","type":"FLOAT","scopes":["CORNER_RADIUS"],"valuesByMode":{"Default":32.0}},{"name":"radius/40","type":"FLOAT","scopes":["CORNER_RADIUS"],"valuesByMode":{"Default":40.0}},{"name":"radius/pill","type":"FLOAT","scopes":["CORNER_RADIUS"],"valuesByMode":{"Default":9999}}]},{"name":"Spiro Stroke","modes":["Default"],"variables":[{"name":"stroke/0","type":"FLOAT","scopes":["STROKE_FLOAT"],"valuesByMode":{"Default":0}},{"name":"stroke/1","type":"FLOAT","scopes":["STROKE_FLOAT"],"valuesByMode":{"Default":1}},{"name":"stroke/2","type":"FLOAT","scopes":["STROKE_FLOAT"],"valuesByMode":{"Default":2}},{"name":"stroke/3","type":"FLOAT","scopes":["STROKE_FLOAT"],"valuesByMode":{"Default":3}}]},{"name":"Spiro Opacity","modes":["Default"],"variables":[{"name":"opacity/0","type":"FLOAT","scopes":["OPACITY"],"valuesByMode":{"Default":0}},{"name":"opacity/1","type":"FLOAT","scopes":["OPACITY"],"valuesByMode":{"Default":1}},{"name":"opacity/5","type":"FLOAT","scopes":["OPACITY"],"valuesByMode":{"Default":5}},{"name":"opacity/10","type":"FLOAT","scopes":["OPACITY"],"valuesByMode":{"Default":10}},{"name":"opacity/25","type":"FLOAT","scopes":["OPACITY"],"valuesByMode":{"Default":25}},{"name":"opacity/50","type":"FLOAT","scopes":["OPACITY"],"valuesByMode":{"Default":50}},{"name":"opacity/75","type":"FLOAT","scopes":["OPACITY"],"valuesByMode":{"Default":75}},{"name":"opacity/100","type":"FLOAT","scopes":["OPACITY"],"valuesByMode":{"Default":100}}]}],"textStyles":[{"name":"display-72","fontFamily":"Clash Grotesk","fontStyle":"Semibold","fontStyleFallbacks":["SemiBold","Regular"],"fontSize":72.0,"lineHeight":{"unit":"PIXELS","value":75.6},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"display-56","fontFamily":"Clash Grotesk","fontStyle":"Semibold","fontStyleFallbacks":["SemiBold","Regular"],"fontSize":56.0,"lineHeight":{"unit":"PIXELS","value":60.48},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"display-44","fontFamily":"Clash Grotesk","fontStyle":"Semibold","fontStyleFallbacks":["SemiBold","Regular"],"fontSize":44.0,"lineHeight":{"unit":"PIXELS","value":48.4},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"display-36","fontFamily":"Clash Grotesk","fontStyle":"Semibold","fontStyleFallbacks":["SemiBold","Regular"],"fontSize":36.0,"lineHeight":{"unit":"PIXELS","value":41.4},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"display-30","fontFamily":"Clash Grotesk","fontStyle":"Semibold","fontStyleFallbacks":["SemiBold","Regular"],"fontSize":30.0,"lineHeight":{"unit":"PIXELS","value":36.0},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"heading-40","fontFamily":"DM Sans","fontStyle":"SemiBold","fontStyleFallbacks":["Regular"],"fontSize":40.0,"lineHeight":{"unit":"PIXELS","value":46.0},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"heading-36","fontFamily":"DM Sans","fontStyle":"SemiBold","fontStyleFallbacks":["Regular"],"fontSize":36.0,"lineHeight":{"unit":"PIXELS","value":43.2},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"heading-30","fontFamily":"DM Sans","fontStyle":"SemiBold","fontStyleFallbacks":["Regular"],"fontSize":30.0,"lineHeight":{"unit":"PIXELS","value":37.5},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"heading-28","fontFamily":"DM Sans","fontStyle":"SemiBold","fontStyleFallbacks":["Regular"],"fontSize":28.0,"lineHeight":{"unit":"PIXELS","value":35.56},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"heading-24","fontFamily":"DM Sans","fontStyle":"SemiBold","fontStyleFallbacks":["Regular"],"fontSize":24.0,"lineHeight":{"unit":"PIXELS","value":31.2},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"heading-20","fontFamily":"DM Sans","fontStyle":"SemiBold","fontStyleFallbacks":["Regular"],"fontSize":20.0,"lineHeight":{"unit":"PIXELS","value":27.0},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"heading-18","fontFamily":"DM Sans","fontStyle":"SemiBold","fontStyleFallbacks":["Regular"],"fontSize":18.0,"lineHeight":{"unit":"PIXELS","value":25.2},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"heading-16","fontFamily":"DM Sans","fontStyle":"SemiBold","fontStyleFallbacks":["Regular"],"fontSize":16.0,"lineHeight":{"unit":"PIXELS","value":22.4},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"body-24","fontFamily":"DM Sans","fontStyle":"Regular","fontStyleFallbacks":[],"fontSize":24.0,"lineHeight":{"unit":"PIXELS","value":36.0},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"body-20","fontFamily":"DM Sans","fontStyle":"Regular","fontStyleFallbacks":[],"fontSize":20.0,"lineHeight":{"unit":"PIXELS","value":30.0},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"body-18","fontFamily":"DM Sans","fontStyle":"Regular","fontStyleFallbacks":[],"fontSize":18.0,"lineHeight":{"unit":"PIXELS","value":27.9},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"body-16","fontFamily":"DM Sans","fontStyle":"Regular","fontStyleFallbacks":[],"fontSize":16.0,"lineHeight":{"unit":"PIXELS","value":24.0},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"body-14","fontFamily":"DM Sans","fontStyle":"Regular","fontStyleFallbacks":[],"fontSize":14.0,"lineHeight":{"unit":"PIXELS","value":21.0},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"body-12","fontFamily":"DM Sans","fontStyle":"Regular","fontStyleFallbacks":[],"fontSize":12.0,"lineHeight":{"unit":"PIXELS","value":18.0},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"label-18","fontFamily":"DM Sans","fontStyle":"SemiBold","fontStyleFallbacks":["Regular"],"fontSize":18.0,"lineHeight":{"unit":"PIXELS","value":19.8},"letterSpacing":{"unit":"PERCENT","value":0.0},"textCase":"UPPER"},{"name":"label-14","fontFamily":"DM Sans","fontStyle":"SemiBold","fontStyleFallbacks":["Regular"],"fontSize":14.0,"lineHeight":{"unit":"PIXELS","value":15.4},"letterSpacing":{"unit":"PERCENT","value":0.0},"textCase":"UPPER"},{"name":"label-12","fontFamily":"DM Sans","fontStyle":"SemiBold","fontStyleFallbacks":["Regular"],"fontSize":12.0,"lineHeight":{"unit":"PIXELS","value":13.2},"letterSpacing":{"unit":"PERCENT","value":0.0},"textCase":"UPPER"},{"name":"button-20","fontFamily":"DM Sans","fontStyle":"SemiBold","fontStyleFallbacks":["Regular"],"fontSize":20.0,"lineHeight":{"unit":"PIXELS","value":20.0},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"button-18","fontFamily":"DM Sans","fontStyle":"SemiBold","fontStyleFallbacks":["Regular"],"fontSize":18.0,"lineHeight":{"unit":"PIXELS","value":18.0},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"button-16","fontFamily":"DM Sans","fontStyle":"SemiBold","fontStyleFallbacks":["Regular"],"fontSize":16.0,"lineHeight":{"unit":"PIXELS","value":16.0},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"quote-36","fontFamily":"Kalam","fontStyle":"Regular","fontStyleFallbacks":[],"fontSize":36.0,"lineHeight":{"unit":"PIXELS","value":46.8},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"quote-24","fontFamily":"Kalam","fontStyle":"Regular","fontStyleFallbacks":[],"fontSize":24.0,"lineHeight":{"unit":"PIXELS","value":33.6},"letterSpacing":{"unit":"PERCENT","value":-2.0}},{"name":"quote-20","fontFamily":"Kalam","fontStyle":"Bold","fontStyleFallbacks":["Regular"],"fontSize":20.0,"lineHeight":{"unit":"PIXELS","value":28.0},"letterSpacing":{"unit":"PERCENT","value":-2.0}}],"effectStyles":[{"name":"shadow/xs","effects":[{"type":"DROP_SHADOW","color":{"r":0.058823529411764705,"g":0.054901960784313725,"b":0.1450980392156863,"a":0.05},"offset":{"x":0.0,"y":1.0},"radius":2.0,"spread":0.0,"visible":true,"blendMode":"NORMAL"}]},{"name":"shadow/sm","effects":[{"type":"DROP_SHADOW","color":{"r":0.058823529411764705,"g":0.054901960784313725,"b":0.1450980392156863,"a":0.1},"offset":{"x":0.0,"y":1.0},"radius":3.0,"spread":0.0,"visible":true,"blendMode":"NORMAL"},{"type":"DROP_SHADOW","color":{"r":0.058823529411764705,"g":0.054901960784313725,"b":0.1450980392156863,"a":0.1},"offset":{"x":0.0,"y":1.0},"radius":2.0,"spread":-1.0,"visible":true,"blendMode":"NORMAL"}]},{"name":"shadow/md","effects":[{"type":"DROP_SHADOW","color":{"r":0.058823529411764705,"g":0.054901960784313725,"b":0.1450980392156863,"a":0.1},"offset":{"x":0.0,"y":4.0},"radius":6.0,"spread":-1.0,"visible":true,"blendMode":"NORMAL"},{"type":"DROP_SHADOW","color":{"r":0.058823529411764705,"g":0.054901960784313725,"b":0.1450980392156863,"a":0.08},"offset":{"x":0.0,"y":2.0},"radius":4.0,"spread":-2.0,"visible":true,"blendMode":"NORMAL"}]},{"name":"shadow/lg","effects":[{"type":"DROP_SHADOW","color":{"r":0.058823529411764705,"g":0.054901960784313725,"b":0.1450980392156863,"a":0.1},"offset":{"x":0.0,"y":10.0},"radius":15.0,"spread":-3.0,"visible":true,"blendMode":"NORMAL"},{"type":"DROP_SHADOW","color":{"r":0.058823529411764705,"g":0.054901960784313725,"b":0.1450980392156863,"a":0.08},"offset":{"x":0.0,"y":4.0},"radius":6.0,"spread":-4.0,"visible":true,"blendMode":"NORMAL"}]},{"name":"shadow/xl","effects":[{"type":"DROP_SHADOW","color":{"r":0.058823529411764705,"g":0.054901960784313725,"b":0.1450980392156863,"a":0.1},"offset":{"x":0.0,"y":20.0},"radius":25.0,"spread":-5.0,"visible":true,"blendMode":"NORMAL"},{"type":"DROP_SHADOW","color":{"r":0.058823529411764705,"g":0.054901960784313725,"b":0.1450980392156863,"a":0.05},"offset":{"x":0.0,"y":8.0},"radius":10.0,"spread":-6.0,"visible":true,"blendMode":"NORMAL"}]},{"name":"shadow/2xl","effects":[{"type":"DROP_SHADOW","color":{"r":0.058823529411764705,"g":0.054901960784313725,"b":0.1450980392156863,"a":0.25},"offset":{"x":0.0,"y":25.0},"radius":50.0,"spread":-12.0,"visible":true,"blendMode":"NORMAL"}]},{"name":"shadow/inner","effects":[{"type":"INNER_SHADOW","color":{"r":0.058823529411764705,"g":0.054901960784313725,"b":0.1450980392156863,"a":0.05},"offset":{"x":0.0,"y":2.0},"radius":4.0,"spread":0.0,"visible":true,"blendMode":"NORMAL"}]},{"name":"shadow/focus","effects":[{"type":"DROP_SHADOW","color":{"r":0.18823529411764706,"g":0.2196078431372549,"b":0.9882352941176471,"a":0.45},"offset":{"x":0.0,"y":0.0},"radius":0.0,"spread":3.0,"visible":true,"blendMode":"NORMAL"}]},{"name":"shadow/focus-danger","effects":[{"type":"DROP_SHADOW","color":{"r":0.9372549019607843,"g":0.26666666666666666,"b":0.26666666666666666,"a":0.45},"offset":{"x":0.0,"y":0.0},"radius":0.0,"spread":3.0,"visible":true,"blendMode":"NORMAL"}]}],"paintStyles":[{"name":"gradient/01-feature/brand","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#1F27E5FF"},{"position":1.0,"color":"#151A8FFF"}]},{"name":"gradient/01-feature/dawn","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#FBBF24FF"},{"position":1.0,"color":"#EF4444FF"}]},{"name":"gradient/01-feature/hero","type":"GRADIENT_LINEAR","direction":"diagonal","stops":[{"position":0.0,"color":"#1F27E5FF"},{"position":0.5,"color":"#3038FCFF"},{"position":1.0,"color":"#DFFF04FF"}]},{"name":"gradient/02-fade/amber-bold-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#FEF3C7FF"},{"position":1.0,"color":"#FEF3C700"}]},{"name":"gradient/02-fade/amber-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#FFFBEBFF"},{"position":1.0,"color":"#FFFBEB00"}]},{"name":"gradient/02-fade/blue-bold-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#DADCFFFF"},{"position":1.0,"color":"#DADCFF00"}]},{"name":"gradient/02-fade/blue-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#EEF0FFFF"},{"position":1.0,"color":"#EEF0FF00"}]},{"name":"gradient/02-fade/cream-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#F6F4EEFF"},{"position":1.0,"color":"#F6F4EE00"}]},{"name":"gradient/02-fade/cyan-bold-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#CFFAFEFF"},{"position":1.0,"color":"#CFFAFE00"}]},{"name":"gradient/02-fade/cyan-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#ECFEFFFF"},{"position":1.0,"color":"#ECFEFF00"}]},{"name":"gradient/02-fade/danger-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#FEE2E2FF"},{"position":1.0,"color":"#FEE2E200"}]},{"name":"gradient/02-fade/emerald-bold-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#D1FAE5FF"},{"position":1.0,"color":"#D1FAE500"}]},{"name":"gradient/02-fade/emerald-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#ECFDF5FF"},{"position":1.0,"color":"#ECFDF500"}]},{"name":"gradient/02-fade/indigo-bold-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#E0E7FFFF"},{"position":1.0,"color":"#E0E7FF00"}]},{"name":"gradient/02-fade/indigo-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#EEF2FFFF"},{"position":1.0,"color":"#EEF2FF00"}]},{"name":"gradient/02-fade/info-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#E0F2FEFF"},{"position":1.0,"color":"#E0F2FE00"}]},{"name":"gradient/02-fade/lavender-bold-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#E5E3EBFF"},{"position":1.0,"color":"#E5E3EB00"}]},{"name":"gradient/02-fade/lavender-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#F2F1F6FF"},{"position":1.0,"color":"#F2F1F600"}]},{"name":"gradient/02-fade/lime-bold-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#ECFCCBFF"},{"position":1.0,"color":"#ECFCCB00"}]},{"name":"gradient/02-fade/lime-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#F7FEE7FF"},{"position":1.0,"color":"#F7FEE700"}]},{"name":"gradient/02-fade/mint-bold-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#DCE8DFFF"},{"position":1.0,"color":"#DCE8DF00"}]},{"name":"gradient/02-fade/mint-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#E9F2ECFF"},{"position":1.0,"color":"#E9F2EC00"}]},{"name":"gradient/02-fade/navy-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#0F0E25FF"},{"position":1.0,"color":"#0F0E2500"}]},{"name":"gradient/02-fade/orange-bold-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#FFEDD5FF"},{"position":1.0,"color":"#FFEDD500"}]},{"name":"gradient/02-fade/orange-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#FFF7EDFF"},{"position":1.0,"color":"#FFF7ED00"}]},{"name":"gradient/02-fade/peach-bold-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#E5D8C7FF"},{"position":1.0,"color":"#E5D8C700"}]},{"name":"gradient/02-fade/peach-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#F1ECE3FF"},{"position":1.0,"color":"#F1ECE300"}]},{"name":"gradient/02-fade/periwinkle-bold-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#DBE4EDFF"},{"position":1.0,"color":"#DBE4ED00"}]},{"name":"gradient/02-fade/periwinkle-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#E8EDF3FF"},{"position":1.0,"color":"#E8EDF300"}]},{"name":"gradient/02-fade/pink-bold-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#FCE7F3FF"},{"position":1.0,"color":"#FCE7F300"}]},{"name":"gradient/02-fade/pink-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#FDF2F8FF"},{"position":1.0,"color":"#FDF2F800"}]},{"name":"gradient/02-fade/red-bold-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#FEE2E2FF"},{"position":1.0,"color":"#FEE2E200"}]},{"name":"gradient/02-fade/red-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#FEF2F2FF"},{"position":1.0,"color":"#FEF2F200"}]},{"name":"gradient/02-fade/rose-bold-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#FFE4E6FF"},{"position":1.0,"color":"#FFE4E600"}]},{"name":"gradient/02-fade/rose-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#FFF1F2FF"},{"position":1.0,"color":"#FFF1F200"}]},{"name":"gradient/02-fade/sky-bold-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#E0F2FEFF"},{"position":1.0,"color":"#E0F2FE00"}]},{"name":"gradient/02-fade/sky-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#F0F9FFFF"},{"position":1.0,"color":"#F0F9FF00"}]},{"name":"gradient/02-fade/success-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#D1FAE5FF"},{"position":1.0,"color":"#D1FAE500"}]},{"name":"gradient/02-fade/violet-bold-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#EDE9FEFF"},{"position":1.0,"color":"#EDE9FE00"}]},{"name":"gradient/02-fade/violet-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#F5F3FFFF"},{"position":1.0,"color":"#F5F3FF00"}]},{"name":"gradient/02-fade/volt-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#FBFFE5FF"},{"position":1.0,"color":"#FBFFE500"}]},{"name":"gradient/02-fade/warning-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#FEF3C7FF"},{"position":1.0,"color":"#FEF3C700"}]},{"name":"gradient/02-fade/yellow-bold-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#FEF9C3FF"},{"position":1.0,"color":"#FEF9C300"}]},{"name":"gradient/02-fade/yellow-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#FEFCE8FF"},{"position":1.0,"color":"#FEFCE800"}]},{"name":"gradient/02-fade/zinc-soft-fade","type":"GRADIENT_LINEAR","direction":"vertical","stops":[{"position":0.0,"color":"#F4F4F5FF"},{"position":1.0,"color":"#F4F4F500"}]}],"components":[{"name":"Button"},{"name":"Chip"},{"name":"Input"},{"name":"Badge"},{"name":"Switch"},{"name":"Checkbox"},{"name":"Radio"},{"name":"Tabs"},{"name":"Alert"},{"name":"Modal"},{"name":"Dropdown"},{"name":"Tooltip"},{"name":"Accordion"},{"name":"Toast"}],"obsoletePaintStyles":["gradient/lavender-soft-fade","gradient/lavender-bold-fade","gradient/mint-soft-fade","gradient/mint-bold-fade","gradient/peach-soft-fade","gradient/peach-bold-fade","gradient/periwinkle-soft-fade","gradient/periwinkle-bold-fade","gradient/blue-soft-fade","gradient/blue-bold-fade","gradient/volt-soft-fade","gradient/cream-fade","gradient/zinc-soft-fade","gradient/navy-fade","gradient/success-fade","gradient/warning-fade","gradient/danger-fade","gradient/info-fade","gradient/hero","gradient/dawn","gradient/brand","gradient/orange-soft-fade","gradient/orange-bold-fade","gradient/amber-soft-fade","gradient/amber-bold-fade","gradient/yellow-soft-fade","gradient/yellow-bold-fade","gradient/lime-soft-fade","gradient/lime-bold-fade","gradient/emerald-soft-fade","gradient/emerald-bold-fade","gradient/cyan-soft-fade","gradient/cyan-bold-fade","gradient/sky-soft-fade","gradient/sky-bold-fade","gradient/indigo-soft-fade","gradient/indigo-bold-fade","gradient/violet-soft-fade","gradient/violet-bold-fade","gradient/pink-soft-fade","gradient/pink-bold-fade","gradient/rose-soft-fade","gradient/rose-bold-fade","gradient/red-soft-fade","gradient/red-bold-fade"]};

// =====================================================================
// Color helpers
// =====================================================================
function hexToRgb(hex) {
  if (!hex) return { r: 0, g: 0, b: 0, a: 1 };
  let h = hex.replace('#', '');
  let a = 1;
  if (h.length === 3) h = h.split('').map(c => c + c).join('');
  if (h.length === 8) {
    a = parseInt(h.slice(6, 8), 16) / 255;
    h = h.slice(0, 6);
  }
  const num = parseInt(h, 16);
  return {
    r: ((num >> 16) & 255) / 255,
    g: ((num >> 8)  & 255) / 255,
    b: ( num        & 255) / 255,
    a: a,
  };
}

function send(text, level) {
  figma.ui.postMessage({ type: 'log', text: text, level: level });
}

// Variable cache for component-build perf
let _varCache = null;
async function loadVarCache() {
  const all = await figma.variables.getLocalVariablesAsync();
  _varCache = new Map();
  for (const v of all) _varCache.set(v.name, v);
}
function findVar(name) { return _varCache ? _varCache.get(name) : undefined; }

function solidWithVar(varName, fallbackHex) {
  const v = findVar(varName);
  const fb = hexToRgb(fallbackHex || "#000000");
  const paint = { type: 'SOLID', color: { r: fb.r, g: fb.g, b: fb.b }, opacity: fb.a };
  if (v) return figma.variables.setBoundVariableForPaint(paint, 'color', v);
  return paint;
}
function setFill(node, varName, fallbackHex) { node.fills = [solidWithVar(varName, fallbackHex)]; }
function clearFill(node) { node.fills = []; }
function setStroke(node, varName, weight, fallbackHex) {
  node.strokes = [solidWithVar(varName, fallbackHex)];
  node.strokeWeight = weight;
}

// =====================================================================
// Geometry bindings — tie corner radius / padding / spacing / stroke
// to variables so editing the token in Figma updates every component.
// =====================================================================
function bindCornerRadius(node, varName, fallbackPx) {
  if (fallbackPx != null) node.cornerRadius = fallbackPx;
  const v = findVar(varName);
  if (v) {
    ['topLeftRadius', 'topRightRadius', 'bottomLeftRadius', 'bottomRightRadius'].forEach(field => {
      try { node.setBoundVariable(field, v); } catch (e) {}
    });
  }
}
function bindPadding(node, varNameX, varNameY, fbX, fbY) {
  const vx = findVar(varNameX), vy = findVar(varNameY);
  if (fbX != null) { node.paddingLeft = fbX; node.paddingRight = fbX; }
  if (fbY != null) { node.paddingTop = fbY; node.paddingBottom = fbY; }
  if (vx) { try { node.setBoundVariable('paddingLeft', vx); } catch (e) {} try { node.setBoundVariable('paddingRight', vx); } catch (e) {} }
  if (vy) { try { node.setBoundVariable('paddingTop', vy); } catch (e) {} try { node.setBoundVariable('paddingBottom', vy); } catch (e) {} }
}
function bindItemSpacing(node, varName, fallbackPx) {
  if (fallbackPx != null) node.itemSpacing = fallbackPx;
  const v = findVar(varName);
  if (v) try { node.setBoundVariable('itemSpacing', v); } catch (e) {}
}
function bindStrokeWeight(node, varName, fallbackPx) {
  if (fallbackPx != null) node.strokeWeight = fallbackPx;
  const v = findVar(varName);
  if (v) try { node.setBoundVariable('strokeWeight', v); } catch (e) {}
}

// =====================================================================
// Text + auto-layout helpers
// =====================================================================
async function makeText(content, styleName, varName, fallbackHex) {
  const text = figma.createText();
  const styles = await figma.getLocalTextStylesAsync();
  const style = styles.find(s => s.name === styleName);
  if (style) {
    await figma.loadFontAsync(style.fontName);
    text.fontName = style.fontName;
    text.characters = content;
    await text.setTextStyleIdAsync(style.id);
  } else {
    await figma.loadFontAsync({ family: 'DM Sans', style: 'Regular' });
    text.characters = content;
  }
  if (varName) setFill(text, varName, fallbackHex);
  return text;
}

function autoLayout(frame, opts) {
  opts = opts || {};
  frame.layoutMode = opts.direction || 'HORIZONTAL';
  if (opts.alignH) frame.primaryAxisAlignItems = opts.alignH;
  if (opts.alignV) frame.counterAxisAlignItems = opts.alignV;
  frame.fills = [];
}

// Standard icon placeholder — a small filled circle.
// Designers swap it for a real icon component after import.
function makeIconPlaceholder(size, varName, fallbackHex) {
  const icon = figma.createEllipse();
  icon.resize(size, size);
  icon.name = 'icon';
  setFill(icon, varName, fallbackHex);
  return icon;
}

// =====================================================================
// Variable / Text / Effect / Gradient imports (existing logic)
// =====================================================================
async function cleanupObsolete() {
  const names = new Set(DATA.obsoleteVariables || []);
  if (names.size > 0) {
    let removed = 0;
    const all = await figma.variables.getLocalVariablesAsync();
    for (const v of all) if (names.has(v.name)) { v.remove(); removed += 1; }
    if (removed > 0) send('Removed ' + removed + ' obsolete variables', 'warn');
  }
  const styleNames = new Set(DATA.obsoleteTextStyles || []);
  if (styleNames.size > 0) {
    let removed = 0;
    const all = await figma.getLocalTextStylesAsync();
    for (const s of all) if (styleNames.has(s.name)) { s.remove(); removed += 1; }
    if (removed > 0) send('Removed ' + removed + ' obsolete text styles', 'warn');
  }
  const paintNames = new Set(DATA.obsoletePaintStyles || []);
  if (paintNames.size > 0) {
    let removed = 0;
    const all = await figma.getLocalPaintStylesAsync();
    for (const s of all) if (paintNames.has(s.name)) { s.remove(); removed += 1; }
    if (removed > 0) send('Removed ' + removed + ' obsolete paint styles', 'warn');
  }
}

async function getOrCreateCollection(name, modes) {
  const existing = (await figma.variables.getLocalVariableCollectionsAsync())
    .find(c => c.name === name);
  if (existing) {
    const existingNames = existing.modes.map(m => m.name);
    modes.forEach(m => { if (!existingNames.includes(m)) existing.addMode(m); });
    if (existing.modes[0].name !== modes[0]) {
      existing.renameMode(existing.modes[0].modeId, modes[0]);
    }
    return existing;
  }
  const col = figma.variables.createVariableCollection(name);
  col.renameMode(col.modes[0].modeId, modes[0]);
  for (let i = 1; i < modes.length; i++) col.addMode(modes[i]);
  return col;
}

async function findVariableInCollection(collection, name) {
  for (const id of collection.variableIds) {
    const v = await figma.variables.getVariableByIdAsync(id);
    if (v && v.name === name) return v;
  }
  return null;
}

async function importCollection(collDef) {
  send('Collection: ' + collDef.name);
  const col = await getOrCreateCollection(collDef.name, collDef.modes);
  const modeIds = {};
  col.modes.forEach(m => { modeIds[m.name] = m.modeId; });
  let created = 0, updated = 0;
  for (const v of collDef.variables) {
    let variable = await findVariableInCollection(col, v.name);
    if (!variable) {
      variable = figma.variables.createVariable(v.name, col, v.type);
      created += 1;
    } else {
      updated += 1;
    }
    if (v.scopes && Array.isArray(v.scopes)) {
      try { variable.scopes = v.scopes; } catch (e) {}
    }
    for (const modeName of collDef.modes) {
      const raw = v.valuesByMode[modeName];
      if (raw === undefined || raw === null) continue;
      let val;
      if (v.type === 'COLOR') val = hexToRgb(raw);
      else if (v.type === 'FLOAT') val = Number(raw);
      else if (v.type === 'STRING') val = String(raw);
      else val = raw;
      variable.setValueForMode(modeIds[modeName], val);
    }
  }
  send('  ' + created + ' created, ' + updated + ' updated', 'ok');
}

async function loadFirstAvailable(family, candidates) {
  for (const style of candidates) {
    try { await figma.loadFontAsync({ family: family, style: style }); return style; }
    catch (e) {}
  }
  return null;
}

async function importTextStyles() {
  send('Text styles');
  const existing = await figma.getLocalTextStylesAsync();
  let created = 0, updated = 0, failed = 0;
  for (const t of DATA.textStyles) {
    const candidates = [t.fontStyle].concat(t.fontStyleFallbacks || []);
    const resolvedStyle = await loadFirstAvailable(t.fontFamily, candidates);
    if (!resolvedStyle) { failed += 1; continue; }
    let style = existing.find(s => s.name === t.name);
    if (!style) { style = figma.createTextStyle(); style.name = t.name; created += 1; }
    else updated += 1;
    style.fontName = { family: t.fontFamily, style: resolvedStyle };
    style.fontSize = t.fontSize;
    style.lineHeight = t.lineHeight;
    style.letterSpacing = t.letterSpacing;
    style.textCase = t.textCase || 'ORIGINAL';
  }
  send('  ' + created + ' created, ' + updated + ' updated, ' + failed + ' skipped', failed ? 'warn' : 'ok');
}

async function importEffectStyles() {
  if (!DATA.effectStyles || DATA.effectStyles.length === 0) return;
  send('Effect styles');
  const existing = await figma.getLocalEffectStylesAsync();
  let created = 0, updated = 0;
  for (const e of DATA.effectStyles) {
    let style = existing.find(s => s.name === e.name);
    if (!style) { style = figma.createEffectStyle(); style.name = e.name; created += 1; }
    else updated += 1;
    style.effects = e.effects.map(layer => {
      const eff = {
        type: layer.type, color: layer.color,
        offset: layer.offset, radius: layer.radius,
        spread: layer.spread || 0,
        visible: layer.visible !== false,
        blendMode: layer.blendMode || 'NORMAL',
      };
      if (layer.type === 'DROP_SHADOW' && layer.showShadowBehindNode !== undefined) {
        eff.showShadowBehindNode = !!layer.showShadowBehindNode;
      }
      return eff;
    });
  }
  send('  ' + created + ' created, ' + updated + ' updated', 'ok');
}

function gradientTransformFor(direction) {
  if (direction === 'horizontal') return [[1, 0, 0], [0, 1, 0]];
  if (direction === 'diagonal')   return [[0.7071, 0.7071, 0], [-0.7071, 0.7071, 0.5]];
  return [[0, 1, 0], [-1, 0, 1]];
}

async function importGradientStyles() {
  if (!DATA.paintStyles || DATA.paintStyles.length === 0) return;
  send('Gradient styles');
  const existing = await figma.getLocalPaintStylesAsync();
  let created = 0, updated = 0;
  for (const g of DATA.paintStyles) {
    let style = existing.find(s => s.name === g.name);
    if (!style) { style = figma.createPaintStyle(); style.name = g.name; created += 1; }
    else updated += 1;
    const transform = gradientTransformFor(g.direction || 'vertical');
    const stops = g.stops.map(s => ({ position: s.position, color: hexToRgb(s.color) }));
    style.paints = [{
      type: g.type || 'GRADIENT_LINEAR',
      gradientTransform: transform,
      gradientStops: stops,
    }];
  }
  send('  ' + created + ' created, ' + updated + ' updated', 'ok');
}

// =====================================================================
// Component builders
// =====================================================================
function combineAsSet(variants, name) {
  try {
    const set = figma.combineAsVariants(variants, figma.currentPage);
    set.name = name;
    return set;
  } catch (err) {
    // If combining fails, log clearly and clean up the orphans we just made
    // so the file isn't littered.
    send('combineAsVariants FAILED for ' + name + ': ' + (err.message || err), 'err');
    for (const v of variants) {
      try { v.remove(); } catch (e) {}
    }
    throw err;
  }
}

// Patterns matching variant component names per builder. Used to scrub
// orphan components left over from a partial earlier run, before re-creating.
const VARIANT_PATTERNS = {
  Button:    /^Variant=(primary|secondary|ghost|destructive|dark|light), Size=/,
  Chip:      /^State=(default|selected|deselected), Size=/,
  Input:     /^State=(default|focus|error|disabled), Size=/,
  Badge:     /^Tone=(accent|success|warning|danger|info), Type=/,
  Switch:    /^State=(off|on), Disabled=/,
  Checkbox:  /^State=(unchecked|checked|indeterminate), Disabled=/,
  Radio:     /^State=(unselected|selected), Disabled=/,
  Tabs:      /^State=(selected|deselected), Size=(sm|md|lg), Icon=/,
  Alert:     /^Tone=(info|success|warning|danger), Icon=/,
  Modal:     /^Size=(sm|md|lg)$/,
  Dropdown:  /^State=(default|focus|open|disabled), Size=(sm|md|lg)$/,
  Tooltip:   /^Tooltip$/,  // singleton, not a set
  Accordion: /^State=(collapsed|expanded)$/,
  Toast:     /^Tone=(info|success|warning|danger), Close=/,
};

async function removeExistingComponentSet(name) {
  // Remove the component set itself
  for (const node of figma.currentPage.children.slice()) {
    if ((node.type === 'COMPONENT_SET' || node.type === 'COMPONENT') && node.name === name) {
      node.remove();
    }
  }
  // Also remove any orphan top-level components matching the variant name pattern
  // for this builder. Catches the case where an earlier run created variants
  // but combineAsVariants failed mid-flight, leaving them scattered.
  const pattern = VARIANT_PATTERNS[name];
  if (pattern) {
    for (const node of figma.currentPage.children.slice()) {
      if (node.type === 'COMPONENT' && pattern.test(node.name)) {
        node.remove();
      }
    }
  }
}

// Realistic placeholder copy per role — never "Label"
const COPY = {
  button: { primary: 'Book test ride', secondary: 'Learn more', ghost: 'View stations',
            destructive: 'Cancel booking', dark: 'Read the story', light: 'Watch the film' },
  chip:   { default: 'New', selected: 'Active', deselected: 'Pending' },
  tab:    'Lease to own',
  input:  { default: 'Enter your name', focus: 'Enter your name',
            error: 'Required field', disabled: 'Read-only' },
  alert:  { info: ['Heads up', 'Service centres open until 8 PM today.'],
            success: ['Saved', 'Your changes are live.'],
            warning: ['Service due', 'Book your 90-day check soon.'],
            danger: ['Action required', 'Payment failed — retry to continue.'] },
};

// ---------- BUTTON ----------
async function buildButton() {
  await removeExistingComponentSet('Button');
  const variants = [];
  const styles = ['primary', 'secondary', 'ghost', 'destructive', 'dark', 'light'];
  const sizes  = ['sm', 'md', 'lg'];
  const states = ['default', 'disabled'];
  const icons  = ['none', 'prefix', 'suffix'];

  // Larger dimensions per the v0.14 spec — buttons read confidently.
  const sizeSpec = {
    sm: { padXVar: 'space/5', padYVar: 'space/3', gapVar: 'space/2',
          padX: 20, padY: 12, gap: 8,  text: 'button-16', icon: 16 },
    md: { padXVar: 'space/7', padYVar: 'space/4', gapVar: 'space/3',
          padX: 32, padY: 16, gap: 12, text: 'button-18', icon: 18 },
    lg: { padXVar: 'space/8', padYVar: 'space/5', gapVar: 'space/3',
          padX: 40, padY: 20, gap: 12, text: 'button-20', icon: 22 },
  };
  const fillByVariant = {
    primary: 'accent/default', secondary: 'bg/canvas', ghost: null,
    destructive: 'danger/default', dark: 'bg/navy/950', light: 'bg/cream/25',
  };
  const textByVariant = {
    primary: 'fg/onAccent', secondary: 'fg/default', ghost: 'fg/default',
    destructive: 'fg/onAccent', dark: 'bg/cream/25', light: 'bg/navy/950',
  };
  const fillFb = {
    primary: '#3038FC', secondary: '#FBFAF7', ghost: null,
    destructive: '#EF4444', dark: '#0F0E25', light: '#FBFAF7',
  };
  const textFb = {
    primary: '#FBFAF7', secondary: '#18181B', ghost: '#18181B',
    destructive: '#FBFAF7', dark: '#FBFAF7', light: '#0F0E25',
  };

  for (const styleVar of styles) {
    for (const size of sizes) {
      for (const state of states) {
        for (const icon of icons) {
          const c = figma.createComponent();
          c.name = `Variant=${styleVar}, Size=${size}, State=${state}, Icon=${icon}`;
          autoLayout(c, { direction: 'HORIZONTAL', alignH: 'CENTER', alignV: 'CENTER' });
          c.layoutSizingHorizontal = 'HUG';
          c.layoutSizingVertical = 'HUG';
          bindPadding(c, sizeSpec[size].padXVar, sizeSpec[size].padYVar,
                       sizeSpec[size].padX, sizeSpec[size].padY);
          bindItemSpacing(c, sizeSpec[size].gapVar, sizeSpec[size].gap);
          bindCornerRadius(c, 'radius/pill', 9999);

          if (fillByVariant[styleVar]) setFill(c, fillByVariant[styleVar], fillFb[styleVar]);
          else c.fills = [];
          if (styleVar === 'secondary') {
            setStroke(c, 'border/strong', 1, '#D4D4D8');
            bindStrokeWeight(c, 'stroke/1', 1);
          }

          if (icon === 'prefix') {
            c.appendChild(makeIconPlaceholder(sizeSpec[size].icon, textByVariant[styleVar], textFb[styleVar]));
          }
          const label = await makeText(COPY.button[styleVar], sizeSpec[size].text,
                                        textByVariant[styleVar], textFb[styleVar]);
          c.appendChild(label);
          if (icon === 'suffix') {
            c.appendChild(makeIconPlaceholder(sizeSpec[size].icon, textByVariant[styleVar], textFb[styleVar]));
          }

          if (state === 'disabled') c.opacity = 0.55;
          variants.push(c);
        }
      }
    }
  }
  combineAsSet(variants, 'Button');
}

// ---------- CHIP ----------
async function buildChip() {
  await removeExistingComponentSet('Chip');
  const variants = [];
  const states = ['default', 'selected', 'deselected'];
  const sizes = ['sm', 'md'];
  const icons = ['none', 'prefix', 'suffix'];
  const sizeSpec = {
    sm: { padXVar: 'space/3', padYVar: 'space/1', gapVar: 'space/2',
          padX: 12, padY: 4,  gap: 6,  text: 'label-12', icon: 12 },
    md: { padXVar: 'space/4', padYVar: 'space/2', gapVar: 'space/2',
          padX: 16, padY: 8,  gap: 8,  text: 'label-14', icon: 14 },
  };

  for (const state of states) {
    for (const size of sizes) {
      for (const icon of icons) {
        const c = figma.createComponent();
        c.name = `State=${state}, Size=${size}, Icon=${icon}`;
        autoLayout(c, { direction: 'HORIZONTAL', alignH: 'CENTER', alignV: 'CENTER' });
        c.layoutSizingHorizontal = 'HUG';
        c.layoutSizingVertical = 'HUG';
        bindPadding(c, sizeSpec[size].padXVar, sizeSpec[size].padYVar,
                     sizeSpec[size].padX, sizeSpec[size].padY);
        bindItemSpacing(c, sizeSpec[size].gapVar, sizeSpec[size].gap);
        bindCornerRadius(c, 'radius/pill', 9999);

        const fillVar = { default: 'bg/subtle', selected: 'accent/selected', deselected: 'accent/deselected' }[state];
        const textVar = { default: 'fg/default', selected: 'accent/selected-fg', deselected: 'accent/deselected-fg' }[state];
        const fillFb  = { default: '#F4F4F5', selected: '#3038FC', deselected: '#EEF0FF' }[state];
        const textFb  = { default: '#18181B', selected: '#FBFAF7', deselected: '#181EB8' }[state];
        setFill(c, fillVar, fillFb);

        if (icon === 'prefix') c.appendChild(makeIconPlaceholder(sizeSpec[size].icon, textVar, textFb));
        const text = await makeText(COPY.chip[state], sizeSpec[size].text, textVar, textFb);
        c.appendChild(text);
        if (icon === 'suffix') c.appendChild(makeIconPlaceholder(sizeSpec[size].icon, textVar, textFb));
        variants.push(c);
      }
    }
  }
  combineAsSet(variants, 'Chip');
}

// ---------- INPUT ----------
async function buildInput() {
  await removeExistingComponentSet('Input');
  const variants = [];
  const states = ['default', 'focus', 'error', 'disabled'];
  const sizes = ['sm', 'md', 'lg'];
  const icons = ['none', 'prefix', 'suffix'];
  const sizeSpec = {
    sm: { padXVar: 'space/3', padYVar: 'space/2', gapVar: 'space/2',
          padX: 12, padY: 8,  gap: 8,  text: 'body-14', icon: 16 },
    md: { padXVar: 'space/4', padYVar: 'space/3', gapVar: 'space/2',
          padX: 16, padY: 12, gap: 8,  text: 'body-16', icon: 18 },
    lg: { padXVar: 'space/5', padYVar: 'space/4', gapVar: 'space/3',
          padX: 20, padY: 16, gap: 12, text: 'body-18', icon: 20 },
  };
  for (const state of states) {
    for (const size of sizes) {
      for (const icon of icons) {
        const c = figma.createComponent();
        c.name = `State=${state}, Size=${size}, Icon=${icon}`;
        autoLayout(c, { direction: 'HORIZONTAL', alignV: 'CENTER' });
        c.layoutSizingVertical = 'HUG';
        c.resize(280, 40);
        bindPadding(c, sizeSpec[size].padXVar, sizeSpec[size].padYVar,
                     sizeSpec[size].padX, sizeSpec[size].padY);
        bindItemSpacing(c, sizeSpec[size].gapVar, sizeSpec[size].gap);
        bindCornerRadius(c, 'radius/8', 8);
        setFill(c, 'bg/canvas', '#FBFAF7');
        const strokeVar = state === 'focus' ? 'border/focus' :
                          state === 'error' ? 'danger/default' : 'border/default';
        const strokeFb  = state === 'focus' ? '#3038FC' :
                          state === 'error' ? '#EF4444' : '#E4E4E7';
        setStroke(c, strokeVar, state === 'focus' ? 2 : 1, strokeFb);
        bindStrokeWeight(c, state === 'focus' ? 'stroke/2' : 'stroke/1', state === 'focus' ? 2 : 1);

        const textVar = state === 'error' ? 'danger/default' : 'fg/muted';
        const textFb  = state === 'error' ? '#EF4444' : '#52525B';
        if (icon === 'prefix') c.appendChild(makeIconPlaceholder(sizeSpec[size].icon, textVar, textFb));
        const placeholder = await makeText(COPY.input[state], sizeSpec[size].text, textVar, textFb);
        c.appendChild(placeholder);
        if (icon === 'suffix') c.appendChild(makeIconPlaceholder(sizeSpec[size].icon, textVar, textFb));

        if (state === 'disabled') c.opacity = 0.55;
        variants.push(c);
      }
    }
  }
  combineAsSet(variants, 'Input');
}

// ---------- BADGE ----------
async function buildBadge() {
  await removeExistingComponentSet('Badge');
  const variants = [];
  const tones = ['accent', 'success', 'warning', 'danger', 'info'];
  const types = ['dot', 'count'];
  const fillByTone = {
    accent: 'accent/default', success: 'success/default',
    warning: 'warning/default', danger: 'danger/default', info: 'info/default',
  };
  const fillFb = {
    accent: '#3038FC', success: '#10B981',
    warning: '#F59E0B', danger: '#EF4444', info: '#0EA5E9',
  };
  for (const tone of tones) {
    for (const type of types) {
      const c = figma.createComponent();
      c.name = `Tone=${tone}, Type=${type}`;
      if (type === 'dot') {
        c.resize(8, 8);
        bindCornerRadius(c, 'radius/pill', 9999);
      } else {
        autoLayout(c, { direction: 'HORIZONTAL', alignH: 'CENTER', alignV: 'CENTER' });
        c.layoutSizingHorizontal = 'HUG';
        c.layoutSizingVertical = 'HUG';
        bindPadding(c, 'space/2', 'space/0', 8, 0);
        bindCornerRadius(c, 'radius/pill', 9999);
        const text = await makeText('9', 'label-12', 'fg/onAccent', '#FBFAF7');
        c.appendChild(text);
      }
      setFill(c, fillByTone[tone], fillFb[tone]);
      variants.push(c);
    }
  }
  combineAsSet(variants, 'Badge');
}

// ---------- SWITCH ----------
async function buildSwitch() {
  await removeExistingComponentSet('Switch');
  const variants = [];
  for (const state of ['off', 'on']) {
    for (const disabled of [false, true]) {
      const c = figma.createComponent();
      c.name = `State=${state}, Disabled=${disabled}`;
      autoLayout(c, { direction: 'HORIZONTAL', alignV: 'CENTER',
                      alignH: state === 'on' ? 'MAX' : 'MIN' });
      c.resize(40, 24);
      bindPadding(c, 'space/1', 'space/1', 4, 4);
      bindCornerRadius(c, 'radius/pill', 9999);
      setFill(c, state === 'on' ? 'accent/default' : 'bg/muted',
              state === 'on' ? '#3038FC' : '#EEEBE1');
      const thumb = figma.createEllipse();
      thumb.resize(16, 16);
      setFill(thumb, 'fg/onAccent', '#FFFFFF');
      c.appendChild(thumb);
      if (disabled) c.opacity = 0.55;
      variants.push(c);
    }
  }
  combineAsSet(variants, 'Switch');
}

// ---------- CHECKBOX ----------
async function buildCheckbox() {
  await removeExistingComponentSet('Checkbox');
  const variants = [];

  // Real checkmark via SVG path — replaces the broken rotated-rectangle hack.
  const checkSvg = '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14"><path d="M3 7.5 L6 10.5 L11.5 4" fill="none" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  for (const state of ['unchecked', 'checked', 'indeterminate']) {
    for (const disabled of [false, true]) {
      const c = figma.createComponent();
      c.name = `State=${state}, Disabled=${disabled}`;
      autoLayout(c, { direction: 'HORIZONTAL', alignH: 'CENTER', alignV: 'CENTER' });
      c.resize(18, 18);
      bindCornerRadius(c, 'radius/4', 4);

      if (state === 'unchecked') {
        clearFill(c);
        setStroke(c, 'border/strong', 1.5, '#D4D4D8');
        bindStrokeWeight(c, 'stroke/2', 1.5);
      } else {
        setFill(c, 'accent/default', '#3038FC');
        if (state === 'checked') {
          // Import as SVG, then re-bind stroke to fg/onAccent so it flips with theme.
          const check = figma.createNodeFromSvg(checkSvg);
          for (const child of check.findAll(n => n.type === 'VECTOR')) {
            setStroke(child, 'fg/onAccent', 2, '#FFFFFF');
          }
          c.appendChild(check);
        } else {
          // Indeterminate — single horizontal bar
          const bar = figma.createRectangle();
          bar.resize(10, 2);
          setFill(bar, 'fg/onAccent', '#FFFFFF');
          c.appendChild(bar);
        }
      }
      if (disabled) c.opacity = 0.55;
      variants.push(c);
    }
  }
  combineAsSet(variants, 'Checkbox');
}

// ---------- RADIO ----------
async function buildRadio() {
  await removeExistingComponentSet('Radio');
  const variants = [];
  for (const state of ['unselected', 'selected']) {
    for (const disabled of [false, true]) {
      const c = figma.createComponent();
      c.name = `State=${state}, Disabled=${disabled}`;
      c.resize(18, 18);
      bindCornerRadius(c, 'radius/pill', 9999);
      clearFill(c);
      setStroke(c,
        state === 'selected' ? 'accent/default' : 'border/strong',
        state === 'selected' ? 5 : 1.5,
        state === 'selected' ? '#3038FC' : '#D4D4D8');
      if (disabled) c.opacity = 0.55;
      variants.push(c);
    }
  }
  combineAsSet(variants, 'Radio');
}

// ---------- TABS / SEGMENT ----------
// Tabs share the button geometry — they're functionally pill toggles.
async function buildTabs() {
  await removeExistingComponentSet('Tabs');
  const variants = [];
  const sizes = ['sm', 'md', 'lg'];
  const icons = ['none', 'prefix', 'suffix'];
  const sizeSpec = {
    sm: { padXVar: 'space/5', padYVar: 'space/3', gapVar: 'space/2',
          padX: 20, padY: 12, gap: 8,  text: 'button-16', icon: 16 },
    md: { padXVar: 'space/7', padYVar: 'space/4', gapVar: 'space/3',
          padX: 32, padY: 16, gap: 12, text: 'button-18', icon: 18 },
    lg: { padXVar: 'space/8', padYVar: 'space/5', gapVar: 'space/3',
          padX: 40, padY: 20, gap: 12, text: 'button-20', icon: 22 },
  };
  for (const state of ['selected', 'deselected']) {
    for (const size of sizes) {
      for (const icon of icons) {
        const c = figma.createComponent();
        c.name = `State=${state}, Size=${size}, Icon=${icon}`;
        autoLayout(c, { direction: 'HORIZONTAL', alignH: 'CENTER', alignV: 'CENTER' });
        c.layoutSizingHorizontal = 'HUG';
        c.layoutSizingVertical = 'HUG';
        bindPadding(c, sizeSpec[size].padXVar, sizeSpec[size].padYVar,
                     sizeSpec[size].padX, sizeSpec[size].padY);
        bindItemSpacing(c, sizeSpec[size].gapVar, sizeSpec[size].gap);
        bindCornerRadius(c, 'radius/pill', 9999);

        const fillVar = state === 'selected' ? 'accent/selected' : 'accent/deselected';
        const textVar = state === 'selected' ? 'accent/selected-fg' : 'accent/deselected-fg';
        const fillFb = state === 'selected' ? '#3038FC' : '#EEF0FF';
        const textFb = state === 'selected' ? '#FBFAF7' : '#181EB8';
        setFill(c, fillVar, fillFb);

        if (icon === 'prefix') c.appendChild(makeIconPlaceholder(sizeSpec[size].icon, textVar, textFb));
        const text = await makeText(COPY.tab, sizeSpec[size].text, textVar, textFb);
        c.appendChild(text);
        if (icon === 'suffix') c.appendChild(makeIconPlaceholder(sizeSpec[size].icon, textVar, textFb));
        variants.push(c);
      }
    }
  }
  combineAsSet(variants, 'Tabs');
}

// ---------- ALERT ----------
async function buildAlert() {
  await removeExistingComponentSet('Alert');
  const variants = [];
  const tones = ['info', 'success', 'warning', 'danger'];
  const fbBg = { info: '#E0F2FE', success: '#D1FAE5', warning: '#FEF3C7', danger: '#FEE2E2' };
  const fbBorder = { info: '#0EA5E9', success: '#10B981', warning: '#F59E0B', danger: '#EF4444' };
  const fbFg = { info: '#0369A1', success: '#047857', warning: '#B45309', danger: '#B91C1C' };

  for (const tone of tones) {
    for (const showIcon of [true, false]) {
      const c = figma.createComponent();
      c.name = `Tone=${tone}, Icon=${showIcon ? 'with' : 'without'}`;
      autoLayout(c, { direction: 'HORIZONTAL', alignV: 'MIN' });
      c.resize(360, 56);
      c.layoutSizingVertical = 'HUG';
      bindPadding(c, 'space/4', 'space/4', 16, 16);
      bindItemSpacing(c, 'space/3', 12);
      bindCornerRadius(c, 'radius/8', 8);
      setFill(c, `${tone}/bg`, fbBg[tone]);
      setStroke(c, `${tone}/default`, 1, fbBorder[tone]);
      bindStrokeWeight(c, 'stroke/1', 1);

      if (showIcon) {
        c.appendChild(makeIconPlaceholder(20, `${tone}/fg`, fbFg[tone]));
      }
      const col = figma.createFrame();
      autoLayout(col, { direction: 'VERTICAL' });
      bindItemSpacing(col, 'space/1', 4);
      col.fills = [];
      const [titleStr, bodyStr] = COPY.alert[tone];
      const title = await makeText(titleStr, 'heading-16', `${tone}/fg`, fbFg[tone]);
      const body = await makeText(bodyStr, 'body-14', `${tone}/fg`, fbFg[tone]);
      col.appendChild(title);
      col.appendChild(body);
      // Append THEN set FILL — FILL only valid on children of auto-layout
      // frames, so the parent attachment must happen first.
      c.appendChild(col);
      col.layoutSizingHorizontal = 'FILL';
      col.layoutSizingVertical = 'HUG';
      variants.push(c);
    }
  }
  combineAsSet(variants, 'Alert');
}

// ---------- MODAL ----------
async function buildModal() {
  await removeExistingComponentSet('Modal');
  const variants = [];
  const widths = { sm: 320, md: 480, lg: 640 };

  for (const size of ['sm', 'md', 'lg']) {
    const c = figma.createComponent();
    c.name = `Size=${size}`;
    autoLayout(c, { direction: 'VERTICAL' });
    c.resize(widths[size], 200);
    c.layoutSizingVertical = 'HUG';
    bindCornerRadius(c, 'radius/16', 16);
    bindPadding(c, 'space/6', 'space/6', 24, 24);
    bindItemSpacing(c, 'space/4', 16);
    setFill(c, 'bg/canvas', '#FBFAF7');
    setStroke(c, 'border/subtle', 1, '#F4F4F5');
    bindStrokeWeight(c, 'stroke/1', 1);

    // Header — title + close icon
    const header = figma.createFrame();
    autoLayout(header, { direction: 'HORIZONTAL', alignH: 'SPACE_BETWEEN', alignV: 'CENTER' });
    header.fills = [];
    bindItemSpacing(header, 'space/3', 12);
    c.appendChild(header);
    header.layoutSizingHorizontal = 'FILL';
    header.layoutSizingVertical = 'HUG';

    const title = await makeText('Confirm action', 'heading-20', 'fg/default', '#18181B');
    header.appendChild(title);

    const closeIcon = makeIconPlaceholder(20, 'fg/muted', '#52525B');
    header.appendChild(closeIcon);

    // Body
    const body = await makeText(
      'Are you sure you want to do this? This action cannot be undone.',
      'body-16', 'fg/muted', '#52525B'
    );
    c.appendChild(body);
    body.layoutSizingHorizontal = 'FILL';

    // Actions row — secondary + primary
    const actions = figma.createFrame();
    autoLayout(actions, { direction: 'HORIZONTAL', alignH: 'MAX', alignV: 'CENTER' });
    actions.fills = [];
    bindItemSpacing(actions, 'space/3', 12);
    c.appendChild(actions);
    actions.layoutSizingHorizontal = 'FILL';
    actions.layoutSizingVertical = 'HUG';

    // Secondary button (cancel)
    const cancelBtn = figma.createFrame();
    autoLayout(cancelBtn, { direction: 'HORIZONTAL', alignH: 'CENTER', alignV: 'CENTER' });
    cancelBtn.layoutSizingHorizontal = 'HUG';
    cancelBtn.layoutSizingVertical = 'HUG';
    bindPadding(cancelBtn, 'space/7', 'space/4', 32, 16);
    bindCornerRadius(cancelBtn, 'radius/pill', 9999);
    setStroke(cancelBtn, 'border/strong', 1, '#D4D4D8');
    cancelBtn.fills = [];
    actions.appendChild(cancelBtn);
    const cancelText = await makeText('Cancel', 'button-18', 'fg/default', '#18181B');
    cancelBtn.appendChild(cancelText);

    // Primary button (confirm)
    const confirmBtn = figma.createFrame();
    autoLayout(confirmBtn, { direction: 'HORIZONTAL', alignH: 'CENTER', alignV: 'CENTER' });
    confirmBtn.layoutSizingHorizontal = 'HUG';
    confirmBtn.layoutSizingVertical = 'HUG';
    bindPadding(confirmBtn, 'space/7', 'space/4', 32, 16);
    bindCornerRadius(confirmBtn, 'radius/pill', 9999);
    setFill(confirmBtn, 'accent/default', '#3038FC');
    actions.appendChild(confirmBtn);
    const confirmText = await makeText('Confirm', 'button-18', 'fg/onAccent', '#FBFAF7');
    confirmBtn.appendChild(confirmText);

    variants.push(c);
  }
  combineAsSet(variants, 'Modal');
}

// ---------- SELECT ----------
async function buildSelect() {
  await removeExistingComponentSet('Dropdown');
  const variants = [];
  const states = ['default', 'focus', 'open', 'disabled'];
  const sizes = ['sm', 'md', 'lg'];
  const sizeSpec = {
    sm: { padXVar: 'space/3', padYVar: 'space/2', text: 'body-14', icon: 14, padX: 12, padY: 8 },
    md: { padXVar: 'space/4', padYVar: 'space/3', text: 'body-16', icon: 16, padX: 16, padY: 12 },
    lg: { padXVar: 'space/5', padYVar: 'space/4', text: 'body-18', icon: 20, padX: 20, padY: 16 },
  };
  for (const state of states) {
    for (const size of sizes) {
      const c = figma.createComponent();
      c.name = `State=${state}, Size=${size}`;
      autoLayout(c, { direction: 'HORIZONTAL', alignH: 'SPACE_BETWEEN', alignV: 'CENTER' });
      c.resize(280, 40);
      c.layoutSizingVertical = 'HUG';
      bindPadding(c, sizeSpec[size].padXVar, sizeSpec[size].padYVar,
                  sizeSpec[size].padX, sizeSpec[size].padY);
      bindCornerRadius(c, 'radius/8', 8);
      setFill(c, 'bg/canvas', '#FBFAF7');
      const strokeVar = state === 'focus' || state === 'open' ? 'border/focus' : 'border/default';
      const strokeFb = state === 'focus' || state === 'open' ? '#3038FC' : '#E4E4E7';
      const strokeW = state === 'focus' || state === 'open' ? 2 : 1;
      setStroke(c, strokeVar, strokeW, strokeFb);
      bindStrokeWeight(c, strokeW === 2 ? 'stroke/2' : 'stroke/1', strokeW);

      const text = await makeText('Select an option', sizeSpec[size].text, 'fg/muted', '#52525B');
      c.appendChild(text);
      // Chevron — placeholder ellipse, designers swap for real chevron-down icon
      const chev = makeIconPlaceholder(sizeSpec[size].icon, 'fg/muted', '#52525B');
      c.appendChild(chev);

      if (state === 'disabled') c.opacity = 0.55;
      variants.push(c);
    }
  }
  combineAsSet(variants, 'Dropdown');
}

// ---------- TOOLTIP ----------
async function buildTooltip() {
  await removeExistingComponentSet('Tooltip');
  // Single component — designers rotate for direction.
  const c = figma.createComponent();
  c.name = 'Tooltip';
  autoLayout(c, { direction: 'HORIZONTAL', alignH: 'CENTER', alignV: 'CENTER' });
  c.layoutSizingHorizontal = 'HUG';
  c.layoutSizingVertical = 'HUG';
  bindPadding(c, 'space/3', 'space/2', 12, 8);
  bindCornerRadius(c, 'radius/8', 8);
  // Tooltip is intentionally always-dark — bg.inverse flips with theme too,
  // but tooltips read better as a fixed dark pill regardless of context.
  // Using static navy hex via the bg/navy/950 primitive var.
  setFill(c, 'bg/navy/950', '#0F0E25');
  const text = await makeText('Tooltip text here', 'body-14', 'bg/cream/25', '#FBFAF7');
  c.appendChild(text);
  // Component sets need 2+ variants — wrap as singleton component (no set)
  c.x = 0; c.y = 0;
}

// ---------- ACCORDION ----------
async function buildAccordion() {
  await removeExistingComponentSet('Accordion');
  const variants = [];
  for (const state of ['collapsed', 'expanded']) {
    const c = figma.createComponent();
    c.name = `State=${state}`;
    autoLayout(c, { direction: 'VERTICAL' });
    c.resize(480, 56);
    c.layoutSizingVertical = 'HUG';
    bindPadding(c, 'space/4', 'space/3', 16, 12);
    bindItemSpacing(c, 'space/3', 12);
    bindCornerRadius(c, 'radius/8', 8);
    setFill(c, 'bg/canvas', '#FBFAF7');
    setStroke(c, 'border/subtle', 1, '#F4F4F5');
    bindStrokeWeight(c, 'stroke/1', 1);

    // Header row — title + chevron
    const header = figma.createFrame();
    autoLayout(header, { direction: 'HORIZONTAL', alignH: 'SPACE_BETWEEN', alignV: 'CENTER' });
    header.fills = [];
    bindItemSpacing(header, 'space/3', 12);
    c.appendChild(header);
    header.layoutSizingHorizontal = 'FILL';
    header.layoutSizingVertical = 'HUG';

    const title = await makeText('How does battery swap work?', 'heading-16', 'fg/default', '#18181B');
    header.appendChild(title);
    const chev = makeIconPlaceholder(16, 'fg/muted', '#52525B');
    if (state === 'expanded') chev.rotation = 180;
    header.appendChild(chev);

    if (state === 'expanded') {
      const body = await makeText(
        'Roll into a swap station, slot in your spent battery, take a fresh one — under ninety seconds, no plug, no wait.',
        'body-14', 'fg/muted', '#52525B'
      );
      c.appendChild(body);
      body.layoutSizingHorizontal = 'FILL';
    }
    variants.push(c);
  }
  combineAsSet(variants, 'Accordion');
}

// ---------- TOAST ----------
async function buildToast() {
  await removeExistingComponentSet('Toast');
  const variants = [];
  const tones = ['info', 'success', 'warning', 'danger'];
  const fbBg = { info: '#E0F2FE', success: '#D1FAE5', warning: '#FEF3C7', danger: '#FEE2E2' };
  const fbBorder = { info: '#0EA5E9', success: '#10B981', warning: '#F59E0B', danger: '#EF4444' };
  const fbFg = { info: '#0369A1', success: '#047857', warning: '#B45309', danger: '#B91C1C' };
  const titles = { info: 'New service centre', success: 'Saved', warning: 'Service due', danger: 'Payment failed' };

  for (const tone of tones) {
    for (const close of [true, false]) {
      const c = figma.createComponent();
      c.name = `Tone=${tone}, Close=${close}`;
      autoLayout(c, { direction: 'HORIZONTAL', alignH: 'SPACE_BETWEEN', alignV: 'CENTER' });
      c.resize(360, 48);
      c.layoutSizingVertical = 'HUG';
      bindPadding(c, 'space/4', 'space/3', 16, 12);
      bindItemSpacing(c, 'space/3', 12);
      bindCornerRadius(c, 'radius/8', 8);
      setFill(c, `${tone}/bg`, fbBg[tone]);
      setStroke(c, `${tone}/default`, 1, fbBorder[tone]);
      bindStrokeWeight(c, 'stroke/1', 1);

      // Inner: icon + text
      const inner = figma.createFrame();
      autoLayout(inner, { direction: 'HORIZONTAL', alignV: 'CENTER' });
      inner.fills = [];
      bindItemSpacing(inner, 'space/2', 8);
      c.appendChild(inner);
      inner.layoutSizingHorizontal = 'HUG';
      inner.layoutSizingVertical = 'HUG';

      inner.appendChild(makeIconPlaceholder(18, `${tone}/fg`, fbFg[tone]));
      const title = await makeText(titles[tone], 'body-14', `${tone}/fg`, fbFg[tone]);
      inner.appendChild(title);

      if (close) {
        const closeIcon = makeIconPlaceholder(16, `${tone}/fg`, fbFg[tone]);
        c.appendChild(closeIcon);
      }
      variants.push(c);
    }
  }
  combineAsSet(variants, 'Toast');
}

// ---------- Components orchestrator ----------
async function importComponents() {
  send('Components');
  await loadVarCache();
  for (const family of ['DM Sans', 'Clash Grotesk', 'Kalam']) {
    for (const style of ['Regular', 'Medium', 'SemiBold', 'Semibold', 'Bold']) {
      try { await figma.loadFontAsync({ family, style }); } catch (e) {}
    }
  }
  let n = 0;
  const builders = [
    ['Button',    buildButton],
    ['Chip',      buildChip],
    ['Input',     buildInput],
    ['Badge',     buildBadge],
    ['Switch',    buildSwitch],
    ['Checkbox',  buildCheckbox],
    ['Radio',     buildRadio],
    ['Tabs',      buildTabs],
    ['Alert',     buildAlert],
    ['Modal',     buildModal],
    ['Dropdown',  buildSelect],     // builder is named buildSelect; component is "Dropdown" externally
    ['Tooltip',   buildTooltip],
    ['Accordion', buildAccordion],
    ['Toast',     buildToast],
  ];
  for (const [name, fn] of builders) {
    try {
      await fn();
      n += 1;
      send(`  ${name}: built`, 'ok');
    } catch (err) {
      send(`  ${name}: FAILED — ${err.message || err}`, 'err');
    }
  }
  let y = 0;
  const builderNames = builders.map(b => b[0]);
  for (const node of figma.currentPage.children) {
    if ((node.type === 'COMPONENT_SET' || node.type === 'COMPONENT') &&
        builderNames.indexOf(node.name) >= 0) {
      node.x = 0;
      node.y = y;
      y += node.height + 80;
    }
  }
  send(`  ${n} of ${builders.length} components built`, n === builders.length ? 'ok' : 'warn');
}

// =====================================================================
// Boot
// =====================================================================
figma.showUI(__html__, { width: 380, height: 580 });

const summary = [
  'Variables (semantics → primitives):',
  ...DATA.collections.map(c =>
    '  ' + c.name + '  ' + c.variables.length + ' vars · ' + c.modes.join(' / ')
  ),
  'Text Styles:    ' + DATA.textStyles.length,
  'Effect Styles:  ' + (DATA.effectStyles || []).length,
  'Gradient Styles: ' + (DATA.paintStyles || []).length,
  'Components:     ' + (DATA.components || []).length + ' (with icon variants)',
].join('\n');
figma.ui.postMessage({ type: 'summary', text: summary });

figma.ui.onmessage = async (msg) => {
  if (msg.type === 'close') { figma.closePlugin(); return; }
  if (msg.type !== 'run') return;
  try {
    await cleanupObsolete();
    if (msg.importVars)      for (const c of DATA.collections) await importCollection(c);
    if (msg.importText)      await importTextStyles();
    if (msg.importEffects)   await importEffectStyles();
    if (msg.importGradients) await importGradientStyles();
    if (msg.importComponents) await importComponents();
    figma.ui.postMessage({ type: 'done' });
    figma.notify('Spiro imported');
  } catch (err) {
    send('ERROR: ' + (err.message || err), 'err');
    figma.notify('Import failed — see plugin window for details', { error: true });
  }
};
